import 'dart:io';
import 'package:click_a_clean/ApiHit/Constants/constants.dart';
import 'package:click_a_clean/ApiHit/SharedPrefs/SharedPrefers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../time.dart';
import 'dart:convert';


class BookingTime extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
// TODO: implement createState
    return _LoginScreenstate();
  }
}

class _LoginScreenstate extends State<BookingTime> {
  bool pressAttention = false;
  bool pressAttention1 = false;
  bool pressAttention2 = false;
  bool pressAttention3 = false;
  bool pressAttention4 = false;

  bool pressAttention5 = false;
  bool pressAttention6 = false;
  bool pressAttention7 = false;
  bool pressAttention8 = false;
  bool pressAttention9 = false;
  bool pressAttention10 = false;
  bool pressAttention11 = false;
  bool pressAttention12 = false;
  bool pressAttention13 = false;
  Map SERVICE_TYPE_data;
  List sERVICE_TYPE_LIST_DATA;
  Map CAR_TYPE_data;
  List CAR_TYPE_LIST_DATA;
  String USER_API_KEY;

  Future<dynamic> getData() async {
    SharedPreferences myPrefs = await SharedPreferences.getInstance();
    USER_API_KEY = myPrefs.getString(STORE_PREFS.USER_API_KEY);
    http.Response response =  await http.get(APPURLS_USER.GET_USER_DATE_GET, headers: {
      'x-api-key': USER_API_KEY,
    });
    //await http.get("http://sharpwebstudio.us/clickaclean/api/user/countries");

    CAR_TYPE_data = json.decode(response.body);
    setState(() {
      CAR_TYPE_LIST_DATA = CAR_TYPE_data["data"];
      print("===CAR_TYPE_LIST_DATA data==="+CAR_TYPE_LIST_DATA.toString());
    });

  }
 getRomeListData() async {
   SharedPreferences myPrefs = await SharedPreferences.getInstance();
   final String name = myPrefs.getString('name');
   final int age = myPrefs.getInt('age');
   final bool syncData = myPrefs.getBool('syncData');
   print("=====check shared==="+name +"=="+age.toString() + "==="+syncData.toString());
  }
  Future getDataService() async {
    SharedPreferences myPrefs = await SharedPreferences.getInstance();
    USER_API_KEY = myPrefs.getString(STORE_PREFS.USER_API_KEY);

    http.Response response =  await http.get(APPURLS_USER.GET_USER_CHECK_SERVICE_NAME, headers: {
      'x-api-key': USER_API_KEY,
    });
    //await http.get("http://sharpwebstudio.us/clickaclean/api/user/countries");

    SERVICE_TYPE_data = json.decode(response.body);
    setState(() {
      sERVICE_TYPE_LIST_DATA = SERVICE_TYPE_data["data"];

      print("===CAR_TYPE_LIST_DATA data==="+sERVICE_TYPE_LIST_DATA.toString());


    });

  }
  int _selectedIndex,_selected_Index_second;
  _onSelected(int index) {

    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData();

    getRomeListData();

  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(125, 121, 204, 1),
        title: Text('Car Clean'),
        centerTitle: true,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios, color: Colors.white),    onPressed: () => Navigator.of(context).pop(),)
      ),
      body: SingleChildScrollView(

      child:Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 0, 20),
                child: Center(
                  child: Text(
                      'When would you like your services?',
                      style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 22),
                      textAlign: TextAlign.center
                  ),
                ),),


              Container(
                height: 60,



                ////////
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,

                    shrinkWrap: true,
                    itemCount: CAR_TYPE_LIST_DATA == null ? 0 : CAR_TYPE_LIST_DATA.length,
                    itemBuilder: (BuildContext context, int index) {

                      return GestureDetector(

                          onTap: () {
                            setState(() {
                              _onSelected(index);
                            });


                            // _navigateToNextScreen(context);
                            // _navigateToNextScreen(context,userData[index]['id'].toString());
                            print("${CAR_TYPE_LIST_DATA[index]['id'].toString()}");
                          },
                          child:
                          Container(
                            margin: EdgeInsets.only(left: 5,right: 5),
                            alignment: Alignment.center,


                            child:FlatButton(


                              shape: RoundedRectangleBorder(side: BorderSide(
                                  color: Colors.grey,
                                  width: 1,
                                  style: BorderStyle.solid
                              ), borderRadius: BorderRadius.circular(5)),
                              child: Row(
                                children: <Widget>[

                                  Container(

                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      crossAxisAlignment: CrossAxisAlignment.center,

                                      children: <Widget>[
                                        Container(

                                          child: Text(
                                            "${CAR_TYPE_LIST_DATA[index]["Week"]}",style: TextStyle(
                                            fontSize: 13,
                                          ),
                                          ),
                                        )
                                        ,Container(
                                          child: Text(
                                              "${CAR_TYPE_LIST_DATA[index]["date"]}"
                                          ),
                                        )
                                      ],
                                    ),
                                  ),


                                ],
                              ),),
                            width: 60.0,
                            height: 70.0,
                          ),

//                          Container(
//                              margin: EdgeInsets.only(left: 1.0,right: 1),
//                              width: 132,
//                              color: _selectedIndex != null && _selectedIndex == index
//                                  ? Color.fromRGBO(220,220,220,100)
//                                  : Colors.white,
//                              child: Column(
//                                  mainAxisAlignment: MainAxisAlignment.center,
//                                  children: <Widget>[
//                                    Image.network(CAR_TYPE_LIST_DATA[index]["car_img"],height: 25,width: 84,),
//                                    Text("${CAR_TYPE_LIST_DATA[index]["name"]}"),
//                                    Container(
//                                      width:20,
//                                      height: 20,
//                                      alignment: Alignment.topRight,
//
//                                      // child: Image.asset(_myImage),
////                                      decoration: new BoxDecoration(
////                                          image: new DecorationImage(
////                                              image:
////                                              fit: BoxFit.fill
////                                          )
////                                      )
//
//                                    ),
//                                  ]
//                              )
//
//                          )

                      );

                    }

                ),
              ),
              new Container(
                padding: EdgeInsets.fromLTRB(10, 20, 0, 20),
                child: Center(
                  child: Text(
                      'At what time should the professional\n arrive?',
                      style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 22),
                      textAlign: TextAlign.center
                  ),
                ),
              ),

              new Container(

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,

                      child:FlatButton(
                        color: pressAttention5 ? Color.fromRGBO(220,220,220,100) : Colors.white,
                        onPressed: () => setState(() => pressAttention5 = !pressAttention5),
                        shape: RoundedRectangleBorder(side: BorderSide(
                            color: Color.fromRGBO(220,220,220,100),
                            width: 1,
                            style: BorderStyle.solid
                        ), borderRadius: BorderRadius.circular(5)),
                        child:Container(
                          alignment: Alignment.center,

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[

                                   Container(
                                    child: Column(
                                      children: <Widget>[
                                        Container(
                                          padding: EdgeInsets.all(20.0),
                                          child: Text(
                                            '12:00 pm',style: TextStyle(
                                            fontSize: 15,
                                          ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),


                            ],
                          ),),

                      ),
                      width: 170.0,
                      height: 60.0,),
                    Container(
                      alignment: Alignment.center,

                      child:FlatButton(
                        color: pressAttention6 ? Color.fromRGBO(220,220,220,100) : Colors.white,
                        onPressed: () => setState(() => pressAttention6 = !pressAttention6),
                        shape: RoundedRectangleBorder(side: BorderSide(
                            color: Color.fromRGBO(220,220,220,100),
                            width: 1,
                            style: BorderStyle.solid
                        ), borderRadius: BorderRadius.circular(5)),
                        child:Container(
                          alignment: Alignment.center,

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[

                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '1:00 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),


                            ],
                          ),),

                      ),
                      width: 170.0,
                      height: 60.0,),

                  ],
                ),
              )
              ,  new Container(

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,

                      child:FlatButton(
                        color: pressAttention7 ? Color.fromRGBO(220,220,220,100) : Colors.white,
                        onPressed: () => setState(() => pressAttention7 = !pressAttention7),
                        shape: RoundedRectangleBorder(side: BorderSide(
                            color: Color.fromRGBO(220,220,220,100),
                            width: 1,
                            style: BorderStyle.solid
                        ), borderRadius: BorderRadius.circular(5)),
                        child:Container(
                          alignment: Alignment.center,

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[

                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '1:30 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),


                            ],
                          ),),

                      ),
                      width: 170.0,
                      height: 60.0,),
                    Container(
                      alignment: Alignment.center,

                      child:FlatButton(
                        color: pressAttention8 ? Color.fromRGBO(220,220,220,100) : Colors.white,
                        onPressed: () => setState(() => pressAttention8 = !pressAttention8),
                        shape: RoundedRectangleBorder(side: BorderSide(
                            color: Color.fromRGBO(220,220,220,100),
                            width: 1,
                            style: BorderStyle.solid
                        ), borderRadius: BorderRadius.circular(5)),
                        child:Container(
                          alignment: Alignment.center,

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[

                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '2:00 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),


                            ],
                          ),),

                      ),
                      width: 170.0,
                      height: 60.0,),

                  ],
                ),
              )
              ,  new Container(

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,

                      child:FlatButton(
                        color: pressAttention9 ? Color.fromRGBO(220,220,220,100) : Colors.white,
                        onPressed: () => setState(() => pressAttention9 = !pressAttention9),
                        shape: RoundedRectangleBorder(side: BorderSide(
                            color: Color.fromRGBO(220,220,220,100),
                            width: 1,
                            style: BorderStyle.solid
                        ), borderRadius: BorderRadius.circular(5)),
                        child:Container(
                          alignment: Alignment.center,

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[

                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '2:30 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),


                            ],
                          ),),

                      ),
                      width: 170.0,
                      height: 60.0,),
                    Container(
                      alignment: Alignment.center,

                      child:FlatButton(
                        color: pressAttention10 ? Color.fromRGBO(220,220,220,100) : Colors.white,
                        onPressed: () => setState(() => pressAttention10 = !pressAttention10),
                        shape: RoundedRectangleBorder(side: BorderSide(
                            color: Color.fromRGBO(220,220,220,100),
                            width: 1,
                            style: BorderStyle.solid
                        ), borderRadius: BorderRadius.circular(5)),
                        child:Container(
                          alignment: Alignment.center,

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[

                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '3:00 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),


                            ],
                          ),),

                      ),
                      width: 170.0,
                      height: 60.0,),

                  ],
                ),
              ),

              new Container(

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,

                      child:FlatButton(
                        color: pressAttention11 ? Color.fromRGBO(220,220,220,100) : Colors.white,
                        onPressed: () => setState(() => pressAttention11 = !pressAttention11),
                        shape: RoundedRectangleBorder(side: BorderSide(
                            color: Color.fromRGBO(220,220,220,100),
                            width: 1,
                            style: BorderStyle.solid
                        ), borderRadius: BorderRadius.circular(5)),
                        child:Container(
                          alignment: Alignment.center,

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[

                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '3:30 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),


                            ],
                          ),),

                      ),
                      width: 170.0,
                      height: 60.0,),
                    Container(
                      alignment: Alignment.center,

                      child:FlatButton(
                        color: pressAttention12 ? Color.fromRGBO(220,220,220,100) : Colors.white,
                        onPressed: () => setState(() => pressAttention12 = !pressAttention12),
                        shape: RoundedRectangleBorder(side: BorderSide(
                            color: Color.fromRGBO(220,220,220,100),
                            width: 1,
                            style: BorderStyle.solid
                        ), borderRadius: BorderRadius.circular(5)),
                        child:Container(
                          alignment: Alignment.center,

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[

                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '4:00 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),


                            ],
                          ),),

                      ),
                      width: 170.0,
                      height: 60.0,),

                  ],
                ),
              )
            ],),



        ],

      )),
      bottomNavigationBar: new Container(

        color: Color.fromRGBO(125, 121, 204, 1),
        height: 52,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[


            Align(
              alignment: FractionalOffset.bottomLeft,
              child: FlatButton(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Align(
                          alignment: FractionalOffset.centerLeft,
                          child:FlatButton(
                              onPressed: () {},
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[

                                  Text("\$ 400",style: TextStyle(color: Colors.white,fontSize: 16)),
                                ],)
                          ),),
                      ],),


                  ],
                ),
              ),),



            Align(
              alignment: FractionalOffset.bottomRight,
              child: FlatButton(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Align(
                          alignment: FractionalOffset.center,
                          child:FlatButton(
                              onPressed: () {
                                _navigateToNextScreen(context);
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Text("Continue",style: TextStyle(color: Colors.white,fontSize: 16)),

                                  Icon(
                                      Icons.arrow_forward_ios,color: Colors.white)

                                ],

                              )

                          ),),

                      ],),


                  ],
                ),
              ),),

          ],),
      ),


    ));
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Time()),
    );
  }
}