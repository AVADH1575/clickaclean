
import 'package:click_a_clean/UserEnd/menu_fragment/otp_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../home_widget.dart';

class LoginScreen extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _LoginScreen();
  }
}

class _LoginScreen extends State<LoginScreen> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool _btnEnabled = false;
  bool _isVisible = true;


  void showToast() {
    setState(() {
      _isVisible = !_isVisible;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body: Padding(
            padding: EdgeInsets.all(0),
            child: ListView(
              children: <Widget>[
                Container(
                  color: Color.fromRGBO(125, 121, 204, 1),
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(10),

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0, 3, 0, 0),
                        child: Align(
                          alignment: Alignment.center,
                          child: SvgPicture.asset(
                            'assets/images/white-logo.svg',

                           // fit: BoxFit.contain,
                            height: 50,


                          ),
                        ),
                      ),
                      Container(
                          padding: EdgeInsets.fromLTRB(20, 5, 0, 0),
                          child: Align(
                              alignment: Alignment.topLeft,

                              child: RichText(
                                textAlign: TextAlign.left,
                                text: TextSpan(
                                  text: 'Login/Create Account \n',
                                  style: TextStyle(color: Colors.white,fontSize: 20.0 ), /*defining default style is optional */
                                  children: <TextSpan>[
                                    TextSpan(
                                        text: 'To get personalised experience', style: TextStyle(color: Colors.white,fontSize: 18.0)),

                                  ],
                                ),
                              ),

                             )),
                    ],

                  ),
                ),


                Container(
                padding: EdgeInsets.fromLTRB(20,30,20,0),
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(0,0,0,5),
                  child:
//                  TextField(
//
//                decoration: const InputDecoration(
//                    hintText: "Enter Mobile Number/Email ID",
//                    contentPadding: const EdgeInsets.fromLTRB(0,20,20,20),
//                suffixIcon:
//                IconButton(
//                  icon: Image(image: AssetImage("assets/images/next_icon.png"),height: 40,width: 40),
//
//                  //onPressed: ,
//                )
//
//               // Image(image: AssetImage("assets/images/next_icon.png"),height: 0,width: 0)
//                ),
//
//
//                ),
                   TextFormField(
                      decoration: InputDecoration(
                      hintText: 'Enter Mobile Number/Email ID',

                        suffixIcon: IconButton(
                        icon: Image(image: AssetImage("assets/images/next_icon.png"),height: 40,width: 40),
                           onPressed: () {
                          _navigateToNextScreen(context);
                       //_navigateToNextScreen(context);
                      }),),),),),


//                Container(
//                  alignment: Alignment.center,
//
//                  padding: EdgeInsets.all(30),
//                    child:  Image(image: AssetImage("assets/images/orconnectwith@2x.png"))
////                    child: Text(
////                      'Sign in',
////                      style: TextStyle(fontSize: 20),
////                    )
//                ),

//                Container(
//                    alignment: Alignment.center,
//                    child: Row(
//
//                      mainAxisAlignment: MainAxisAlignment.center,
//                      children: <Widget>[
//                        Padding(
//                          padding: EdgeInsets.all(0),
//                          child: FlatButton.icon(
//                            shape: new RoundedRectangleBorder(
//                                borderRadius: new BorderRadius.circular(10.0),
//                                side: BorderSide(color: Colors.grey)),
//                            color: Colors.white,
//                            icon: Image.asset(
//                              'assets/images/google.png',
//                              fit: BoxFit.contain,
//                              height: 20,
//                              width: 20,
//
//                            ), //`Icon` to display
//                            label: Text('Google')
//                            , //`Text` to display
//                            onPressed: () {
//
//                         _navigateToNextScreen1(context);
//                              //Code to execute when Floating Action Button is clicked
//                              //...
//                            },
//                          ),
//                        ),
//
////                        FlatButton(
////                          shape: new RoundedRectangleBorder(
////                              borderRadius: new BorderRadius.circular(10.0),
////                              side: BorderSide(color: Colors.grey)),
////                          color: Colors.white,
////                          textColor: Colors.grey,
////                          padding: EdgeInsets.all(8.0),
////                          onPressed: () {},
////
////                          child: Text(
////                              "Google".toUpperCase(),
////                            style: TextStyle(
////                              fontSize: 14.0,
////                            ),
////                          ),
////                        ),
//
//                        SizedBox(width: 10),
//                        Padding(
//                          padding: EdgeInsets.fromLTRB(10,0,10,0),
//                          child: FlatButton.icon(
//                            shape: new RoundedRectangleBorder(
//                                borderRadius: new BorderRadius.circular(10.0),
//                                side: BorderSide(color: Colors.grey)),
//                            color: Colors.white,
//                            icon: Image.asset(
//                              'assets/images/facebook.png',
//                              fit: BoxFit.contain,
//                              height: 20,
//                              width: 20,
//
//                            ),//`Icon` to display
//                            label: Text('Facebook')
//                            , //`Text` to display
//                            onPressed: () {
//                              _navigateToNextScreen(context);
//                              //Code to execute when Floating Action Button is clicked
//                              //...
//                            },
//                          ),
//                        ),
//                      ],
//                    )
//                ),

                SizedBox(height: 10),
                Container(
                    padding:EdgeInsets.fromLTRB(10, 15, 10, 0) ,
                    child: Column(
                      children: <Widget>[
                        Center(

                      child: RichText(
                        textAlign: TextAlign.center,
                          text: TextSpan(
                            text: 'Your personal details are secure with us.Read our',
                            style: TextStyle(color: Color.fromRGBO(169, 189, 212, 1),fontSize: 12.5 ), /*defining default style is optional */
                            children: <TextSpan>[
                              TextSpan(
                                  text: ' Privacy', style: TextStyle(fontWeight: FontWeight.bold,color: Color.fromRGBO(241, 123, 72 ,1),fontSize: 12.5)),
                              TextSpan(
                                  text: ' Policy',
                                  style: TextStyle(color: Color.fromRGBO(241, 123, 72 ,1),fontSize: 12.5,fontWeight: FontWeight.bold)),
                              TextSpan(
                                  text: ' to know more.By Proceeding further you agree to our\n',
                                  style: TextStyle(color: Color.fromRGBO(169, 189, 212, 1), fontSize: 12.5)),
                              TextSpan(
                                  text: 'Terms and Conditions ',
                                  style: TextStyle(color: Color.fromRGBO(241, 123, 72 ,1), fontSize: 12.5,fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),),

                        FlatButton(
                          textColor: Colors.grey,
                          onPressed: () {
                            //signup screen
                          },
                        )
                      ],
                      mainAxisAlignment: MainAxisAlignment.center,
                    ))
              ],
            )));
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Otp()),
    );
  }
  void _navigateToNextScreen1(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => HomeScreen_Fragment()),
    );
  }
}
