import 'package:click_a_clean/UserEnd/menu_fragment/home_menu_fragment.dart';
import 'package:click_a_clean/UserEnd/menu_fragment/time.dart';
import 'package:click_a_clean/UserEnd/walk_through/choose_user.dart';
import 'package:click_a_clean/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../home_widget.dart';




class Reschdule extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
// TODO: implement createState
    return _Reschdule();
  }
}

class _Reschdule extends State<Reschdule> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(125, 121, 204, 1),
        title: Text('Car Clean'),
        centerTitle: true,
      ),
      body:  SingleChildScrollView(
       child:Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 0, 20),
                child: Center(
                  child: Text(
                      'When would you like your services?',
                      style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 22),
                      textAlign: TextAlign.center
                  ),
                ),),
              new Container(
                padding: EdgeInsets.all(15.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Thu',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '12'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Fri',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '13'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Sat',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '14'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Sun',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '15'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),

                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Mon',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '16'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                  ],
                ),
              )
              ,
              new Container(
                padding: EdgeInsets.fromLTRB(10, 20, 0, 20),
                child: Center(
                  child: Text(
                      'At what time should the professional\n arrive?',
                      style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 22),
                      textAlign: TextAlign.center
                  ),
                ),
              ),



              new Container(
                padding: EdgeInsets.all(5.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '12:00 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '1 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),

                  ],
                ),
              )
              ,new Container(
                padding: EdgeInsets.all(3.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '1:30 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '2 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),

                  ],
                ),
              ),new Container(

                padding: EdgeInsets.only(top:30),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,

                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                color: Color.fromRGBO(241, 123, 72, 1),
                              ),
                              child: FlatButton(
                                child: Column(
                                  children: <Widget>[
                                    Container(

                                      padding: EdgeInsets.only(top: 10),
                                      child: Text(
                                        'CANCEL',style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 13,
                                      ),
                                      ),
                                    )
                                  ],
                                ),onPressed: (){
                                  _navigateToHomeScreen(context);
                              },
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 140.0,
                      height: 40.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,

                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                color: Color.fromRGBO(125, 121, 204, 1),
                              ),
                              child: FlatButton(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.only(top:10.0),
                                      child: Text(
                                        'RESCHEDULE',style: TextStyle(
                                        fontSize: 13,color: Colors.white
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              onPressed: (){
                                _navigateToNextScreen(context);
                              },),
                            ),
                          )
                        ],
                      ),
                      width: 130.0,
                      height: 40.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                       // border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),

                  ],
                ),
              )


            ],),



        ],

      ),),



    );
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Time()),
    );
  }
  void _navigateToHomeScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) =>  HomeScreen_Fragment()),
    );
  }
}