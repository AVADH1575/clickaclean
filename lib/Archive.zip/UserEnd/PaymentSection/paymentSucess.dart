import 'package:click_a_clean/UserEnd/AddLocation/TrackOrder.dart';
import 'package:click_a_clean/UserEnd/PaymentSection/reschdule.dart';
import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

//import 'add_new_address.dart';

class PaymentSucess extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
// TODO: implement createState
    return _PaymentSucess();
  }
}

class _PaymentSucess extends State<PaymentSucess> {

  int _radioValue1 = -1;
  int correctScore = 0;
  int _radioValue2 = -1;
  int _radioValue3 = -1;
  int _radioValue4 = -1;
  int _radioValue5 = -1;

  void _handleRadioValueChange1(int value) {
    setState(() {
      _radioValue1 = value;

      switch (_radioValue1) {
        case 0:
// Fluttertoast.showToast(msg: 'Correct !',toastLength: Toast.LENGTH_SHORT);
          correctScore++;
          break;
        case 1:
// Fluttertoast.showToast(msg: 'Try again !',toastLength: Toast.LENGTH_SHORT);
          break;
        case 2:
// Fluttertoast.showToast(msg: 'Try again !',toastLength: Toast.LENGTH_SHORT);
          break;
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(125, 121, 204, 1),
        title: Text('Car Clean'),
        centerTitle: true,
      ),
      body:  SingleChildScrollView(
      child:Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Column(

            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                children: <Widget>[

                  Row(
                      children: <Widget>[

                        Container(
                          padding: EdgeInsets.fromLTRB(20, 0, 0, 0),
                          child:
                          FlatButton(

                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [

                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                    Icon(
                                      Icons.insert_drive_file,

                                      size: 16.0,
                                    ),
                                    //SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                    Padding(
                                        padding:  EdgeInsets.fromLTRB(1, 0, 0, 0),
                                        child: Text(
                                            'View Details',
                                            style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 13),
                                            textAlign: TextAlign.start
                                        ))


                                    ,]),



                                  ],),

                              ],
                            ),onPressed: (){

                            _navigateToViewDetail(context);
                          },),
                        ),

                        Container(
                          padding: EdgeInsets.only(left: 6),
                          color: Color.fromRGBO(0, 0, 0, 0.16),
                          height: 50,
                          width: 1,
                        ),



                        Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                          child:
                          FlatButton(

                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Icon(
                                      Icons.access_time,

                                      size: 16.0,
                                    ),

                                    //SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                    Padding(
                                        padding:  EdgeInsets.fromLTRB(5, 0, 0, 0),
                                        child: Text(
                                            'Reschedule',
                                            style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 13),
                                            textAlign: TextAlign.start
                                        ))

                                    ,


                                  ],),

                              ],
                            ),onPressed: (){
                            _navigateToRescheduleScreen(context);
                          },),
                        ),
                        Container(
                          padding: EdgeInsets.only(left: 6),
                          color: Color.fromRGBO(0, 0, 0, 0.16),
                          height: 50,
                          width: 1,
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                          child:
                          FlatButton(

                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(

                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [

                                    Icon(
                                      Icons.delete_forever,

                                      size: 16.0,
                                    ),
                                  //  SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                    Padding(
                                        padding:  EdgeInsets.fromLTRB(5, 0, 0, 0),
                                        child: Text(
                                            'Cancel',
                                            style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 13),
                                            textAlign: TextAlign.start
                                        ))

                                    ,


                                  ],),

                              ],
                            ),onPressed: (){
                            _navigateToHomeScreen(context);
                          },),
                        ),



                      ]),




                ],),



              Divider(
                color: Color.fromRGBO(0, 0, 0, 0.16),
              ),
              new Container(

                child: Column(

                  children: [

                    Padding(
                        padding: EdgeInsets.only(top: 108),

                        child:Image.asset('assets/images/check.png',height: 111,width: 123,)),
                    Padding(
                      padding: EdgeInsets.only(top: 26),
                      child: Text(
                        "Booking Accepted",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 25, color: Color.fromRGBO(76, 217, 100, 1)),

                      ),
                    ),
                    Container(

                      padding: EdgeInsets.only(top:24.0),
                      child: Center(
                        child: Text(
                          "Your Car Cleaner will be \n assigned 1 hour before \n the scheduled time",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 20, color: Color.fromRGBO(145, 145, 145, 1)),

                        ),
                      ),
                    ),

                  ],
                ),

              ),
            ],),



        ],

      ),),
      bottomNavigationBar: new Container(

        color: Color.fromRGBO(125, 121, 204, 1),
        height: 52,

        child:Container(

          color: Color.fromRGBO(125, 121, 204, 1),
      height: 52,

      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[


          Align(
            alignment: FractionalOffset.bottomLeft,
            child: FlatButton(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Align(
                        alignment: FractionalOffset.centerLeft,
                        child:FlatButton(
                            onPressed: () {},
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[

                                Text("",style: TextStyle(color: Colors.white,fontSize: 18)),
                              ],)
                        ),),
                    ],),


                ],
              ),
            ),),



          Align(
            alignment: FractionalOffset.bottomRight,
            child: FlatButton(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Align(
                        alignment: FractionalOffset.center,
                        child:FlatButton(
                            onPressed: () {
                              _navigateToNextScreen(context);
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Text("Continue",style: TextStyle(color: Colors.white,fontSize: 18)),

                                Icon(
                                    Icons.arrow_forward_ios,color: Colors.white)

                              ],

                            )

                        ),),

                    ],),


                ],
              ),
            ),),

        ],),
    ),
      ),


    );
  }
 void _navigateToNextScreen(BuildContext context) {
 Navigator.push(
 context,
 MaterialPageRoute(builder: (context) => Reschdule()),
 );
 }
  void _navigateToHomeScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => HomeScreen_Fragment()),
    );
  }
  void _navigateToViewDetail(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TrackOrder()),
    );
  }
  void _navigateToRescheduleScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Reschdule()),
    );
  }

}