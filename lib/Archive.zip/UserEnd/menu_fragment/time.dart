import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:click_a_clean/UserEnd/AddLocation/address.dart';



class Time extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
// TODO: implement createState
    return _Time();
  }
}

class _Time extends State<Time> {
  bool monVal = false;
  bool tuVal = false;
  bool wedVal = false;
  bool thuVal = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(125, 121, 204, 1),
        title: Text('Car Clean'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
      child:Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 0, 20),
                child: Center(
                  child: Text(
                      'Your Selected Item',
                      style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 22),
                      textAlign: TextAlign.center
                  ),
                ),),
              new Container(

                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),

                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.all(9.0),
                        child: Row(
                          children: [

                            Text(
                                'Date',
                                style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                textAlign: TextAlign.start
                            ),
                            new Container(
                              width: 300,
                              child: Text(
                                  '22/1/2020',
                                  style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                  textAlign: TextAlign.end
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(9.0),
                        child: Row(
                          children: [

                            Text(
                                'Time',
                                style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                textAlign: TextAlign.start
                            ),
                            new Container(
                              width: 300,
                              child: Text(
                                  '10Am',
                                  style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                  textAlign: TextAlign.end
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(9.0),
                        child: Row(
                          children: [

                            Text(
                                'Price',
                                style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                textAlign: TextAlign.start
                            ),
                            new Container(
                              width: 300,
                              child: Text(
                                  '100',
                                  style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                  textAlign: TextAlign.end
                              ),

                            )

                          ],

                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(9.0),
                        child: Row(

                          children: [

                            Text(
                                'Total',
                                style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                textAlign: TextAlign.start
                            ),
                            new Container(
                              width: 300,
                              child: Text(
                                  '400',
                                  style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                  textAlign: TextAlign.end
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),



              new Container(

                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),

                  child: Column(

                    children: [
                      Padding(
                        padding: EdgeInsets.fromLTRB(25, 10, 0, 0),
                        child:Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Car Valeter',
                            style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 17),

                          ),
                        ),),

                      Container(
                        padding: EdgeInsets.all(9.0),

                        child: Row(
                          children: <Widget>[




                            Padding(
                                padding: EdgeInsets.fromLTRB(10, 6, 0, 0),
                                child:Row(

//mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: <Widget>[

                                    Checkbox(
                                      checkColor: Color.fromRGBO(241, 123, 72, 1) ,
                                      focusColor: Color.fromRGBO(241, 123, 72, 1),
                                      activeColor: Colors.white,
                                      hoverColor: Color.fromRGBO(96, 96, 96, 1),
                                      value: monVal,
                                      onChanged: (bool value) {
                                        setState(() {
                                          monVal = value;
                                        });
                                      },
                                    ),
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(0, 5, 23, 0),
                                        child:
                                        Text("Car",
                                          style: TextStyle(color: Color.fromRGBO(96, 96, 96, 1) ,fontSize: 12),textAlign: TextAlign.justify,)
                                    ),
                                    Checkbox(
                                      checkColor: Color.fromRGBO(241, 123, 72, 1) ,
                                      focusColor: Color.fromRGBO(241, 123, 72, 1),
                                      activeColor: Colors.white,
                                      hoverColor: Color.fromRGBO(96, 96, 96, 1),
                                      value:tuVal,
                                      onChanged: (bool value) {
                                        setState(() {
                                          tuVal = value;
                                        });
                                      },
                                    ),
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(0, 5, 23, 0),
                                        child:
                                        Text("4X4",
                                          style: TextStyle(color: Color.fromRGBO(96, 96, 96, 1) ,fontSize: 12),textAlign: TextAlign.justify,)
                                    ),
                                  ],
                                )
                            )






                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(25, 10, 0, 0),
                        child:Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Valeter Type',
                            style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 17),

                          ),
                        ),),
                      Container(


                        child: Row(

                          children: <Widget>[



                            Padding(
                                padding: EdgeInsets.fromLTRB(10, 6, 0, 0),
                                child:Row(

//mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: <Widget>[

                                    Checkbox(
                                      checkColor: Color.fromRGBO(241, 123, 72, 1) ,
                                      focusColor: Color.fromRGBO(241, 123, 72, 1),
                                      activeColor: Colors.white,
                                      hoverColor: Color.fromRGBO(96, 96, 96, 1),
                                      value: wedVal,
                                      onChanged: (bool value) {
                                        setState(() {
                                          wedVal = value;
                                        });
                                      },
                                    ),
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(0, 5, 23, 0),
                                        child:
                                        Text("Valeter1",
                                          style: TextStyle(color: Color.fromRGBO(96, 96, 96, 1) ,fontSize: 12),textAlign: TextAlign.justify,)
                                    ),
                                    Checkbox(
                                      checkColor: Color.fromRGBO(241, 123, 72, 1) ,
                                      focusColor: Color.fromRGBO(241, 123, 72, 1),
                                      activeColor: Colors.white,
                                      hoverColor: Color.fromRGBO(96, 96, 96, 1),
                                      value:thuVal,
                                      onChanged: (bool value) {
                                        setState(() {
                                          thuVal = value;
                                        });
                                      },
                                    ),
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(0, 5, 23, 0),
                                        child:
                                        Text("Valeter2",
                                          style: TextStyle(color: Color.fromRGBO(96, 96, 96, 1) ,fontSize: 12),textAlign: TextAlign.justify,)
                                    ),
                                  ],
                                )
                            )






                          ],
                        ),
                      ),

                      Container(
                        padding: EdgeInsets.all(9.0),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,

                          children: [

                            Text(
                                '\$ 400 ',
                                style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                textAlign: TextAlign.start
                            ),
                            new Container(
                              alignment: Alignment.centerRight,
                              height:40,
                              width:120,
                              padding: EdgeInsets.only(left:20.0),
                              child:Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: <Widget>[
                                  Expanded(
                                    child: Container(

                                      decoration: new BoxDecoration(
                                          borderRadius: BorderRadius.circular(10.0),
                                          color: Colors.white
                                      ),
                                      child: Container(
                                        color: Color.fromRGBO(229, 233, 255, 1),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: <Widget>[
                                            Container(
                                              padding: EdgeInsets.only(left: 8.0,top: 8.0,bottom: 8.0),
                                              child: Text(
                                                'ADD',style: TextStyle(
                                                fontSize: 15,
                                              ),
                                              ),
                                            ),
                                            Icon(Icons.add)
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ],),



        ],

      )),
      bottomNavigationBar: new Container(

        color: Color.fromRGBO(125, 121, 204, 1),
        height: 52,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[


            Align(
              alignment: FractionalOffset.bottomLeft,
              child: FlatButton(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Align(
                          alignment: FractionalOffset.centerLeft,
                          child:FlatButton(
                              onPressed: () {},
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[

                                  Text("\$ 400",style: TextStyle(color: Colors.white,fontSize: 16)),
                                ],)
                          ),),
                      ],),


                  ],
                ),
              ),),



            Align(
              alignment: FractionalOffset.bottomRight,
              child: FlatButton(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Align(
                          alignment: FractionalOffset.center,
                          child:FlatButton(
                              onPressed: () {
                                _navigateToNextScreen(context);
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Text("Continue",style: TextStyle(color: Colors.white,fontSize: 16)),

                                  Icon(
                                      Icons.arrow_forward_ios,color: Colors.white)

                                ],

                              )

                          ),),

                      ],),


                  ],
                ),
              ),),

          ],),
      ),


    );
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Address()),
    );
  }

}