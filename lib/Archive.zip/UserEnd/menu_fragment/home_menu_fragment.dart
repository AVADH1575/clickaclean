import 'package:camera/new/camera.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/PersonalInformation/personal_information_first.dart';
import 'package:click_a_clean/UserEnd/ImagePickerExample.dart';
import 'package:click_a_clean/UserEnd/ImagePickerScreen.dart';
import 'package:click_a_clean/UserEnd/ServiceType/car_velter.dart';
import 'package:click_a_clean/UserEnd/ServiceType/domestic_clean.dart';
import 'package:click_a_clean/UserEnd/camera_screen.dart';
import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:click_a_clean/UserEnd/login/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';




class HomeMenu extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _HomeMenu();
  }
}
class _HomeMenu extends State<HomeMenu> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //appBar: AppBar(title: Text("Account Setup"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),),
        body: Padding(
            padding: EdgeInsets.all(0),
            child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  image: DecorationImage(
                      image: AssetImage('assets/images/home_option.png'),
                      fit: BoxFit.cover
                  ),
                ),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Column(
                        children: <Widget>[

                          Container(
                            height: 49,
                            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                            margin:  EdgeInsets.fromLTRB(0, 35, 0, 0),


                            child: Container(
                              child:
                              Padding(
                                padding: EdgeInsets.fromLTRB(5, 0, 5, 0),

                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: <Widget>[

                                    Text("text",style: TextStyle(color: Colors.transparent, fontSize: 16),),
                                    Text("Please Select Your Service",style: TextStyle(
                                        decoration: TextDecoration.none,
                                        color: Color.fromRGBO(96, 96, 96, 1),
                                        fontWeight: FontWeight.w500,
                                        fontSize: 18)),
                                    IconButton(icon: Icon(Icons.notifications_none,color:  Color.fromRGBO(241, 123, 72, 1)) , onPressed: null)
                                    //Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),

                                  ],
                                ),),

                            ),


                          ),

                          Container(
                              alignment: Alignment.topRight,
                              padding: EdgeInsets.all(10),
                              margin: EdgeInsets.fromLTRB(0, 33, 0, 0),
                              child:
                              Column(
                                //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Text(
                                      'Domestic \n Cleaner',textAlign: TextAlign.center,
                                      style: TextStyle(
                                          decoration: TextDecoration.none,
                                          color: Color.fromRGBO(125, 121, 204, 1),
                                          fontSize: 30),
                                    ),
                                    RaisedButton(
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8)),
                                      textColor: Colors.white,
                                      color: Color.fromRGBO(125, 121, 204, 1),
                                      child: Text('Click Here'),
                                      onPressed: () {
                                        print(nameController.text);
                                        Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
                                            builder: (context) => DomesticCleaner(), maintainState: false));
                                        //_navigateToNextScreen1(context);
                                      },
                                    )
                                  ])
                          ),


                        ],
                      ),
                      Container(
                          alignment: Alignment.topLeft,
                          padding: EdgeInsets.all(10),
                          margin: EdgeInsets.fromLTRB(10, 60, 0, 0),
                          child:
                          Column(
                            //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Car \nValeter',textAlign: TextAlign.left,
                                  style: TextStyle(
                                      decoration: TextDecoration.none,
                                      color: Color.fromRGBO(241, 123, 72 ,1),

                                      fontSize: 30),
                                ),
                                RaisedButton(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                  textColor: Colors.white,
                                  color: Color.fromRGBO(241, 123, 72 ,1),
                                  child: Text('Click Here'),
                                  onPressed: () {
                                    //print(nameController.text);
                                    Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
                                        builder: (context) => CarVelter(), maintainState: false));
                                  },
                                )
                              ])
                      ),
                      Container(
                        height: 0,
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                        margin:  EdgeInsets.fromLTRB(0, 100, 10, 0),

                      ),


                    ]))));
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => PersonalInformationFirst()),
    );
  }
//  void _navigateToNextScreen1(BuildContext context) {
//    Navigator.push(
//      context,
//      MaterialPageRoute(builder: (context) => VerifyIdentyFirst()),
//    );
//  }
//  void _navigateToNextScreen2(BuildContext context) {
//    Navigator.push(
//      context,
//      MaterialPageRoute(builder: (context) => BankDetailFirst()),
//    );
//  }
//  void _navigateToNextScreen3(BuildContext context) {
//    Navigator.push(
//      context,
//      MaterialPageRoute(builder: (context) => ProviderHomeScreenTab()),
//    );
//  }
}