import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../time.dart';



class BookingTime extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
// TODO: implement createState
    return _LoginScreenstate();
  }
}

class _LoginScreenstate extends State<BookingTime> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(125, 121, 204, 1),
        title: Text('Car Clean'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
      child:Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 0, 20),
                child: Center(
                  child: Text(
                      'When would you like your services?',
                      style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 22),
                      textAlign: TextAlign.center
                  ),
                ),),
              new Container(
                padding: EdgeInsets.all(15.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Thu',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '12'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Fri',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '13'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Sat',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '14'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Sun',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '15'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),

                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(10.0),
                                      child: Text(
                                        'Mon',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                    ,Container(
                                      child: Text(
                                          '16'
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 60.0,
                      height: 70.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                  ],
                ),
              )
              ,
              new Container(
                padding: EdgeInsets.fromLTRB(10, 20, 0, 20),
                child: Center(
                  child: Text(
                      'At what time should the professional\n arrive?',
                      style: TextStyle(color: Colors.black.withOpacity(0.7),fontSize: 22),
                      textAlign: TextAlign.center
                  ),
                ),
              ),



              new Container(
                padding: EdgeInsets.all(5.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '12:00 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '1 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),

                  ],
                ),
              )
              ,new Container(
                padding: EdgeInsets.all(3.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '1:30 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '2 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),

                  ],
                ),
              )
              ,new Container(
                padding: EdgeInsets.all(5.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '2:30 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '3 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),


                  ],
                ),
              )
              ,new Container(
                padding: EdgeInsets.all(5.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                              decoration: new BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: Colors.white
                              ),
                              child: Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        '2:30 pm',style: TextStyle(
                                        fontSize: 15,
                                      ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Row(
                        children: <Widget>[

                        ],
                      ),
                      width: 170.0,
                      height: 60.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.rectangle,

                      ),
                    ),


                  ],

                ),
              ),
            ],),



        ],

      )),
      bottomNavigationBar: new Container(

        color: Color.fromRGBO(125, 121, 204, 1),
        height: 52,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[


            Align(
              alignment: FractionalOffset.bottomLeft,
              child: FlatButton(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Align(
                          alignment: FractionalOffset.centerLeft,
                          child:FlatButton(
                              onPressed: () {},
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[

                                  Text("\$ 400",style: TextStyle(color: Colors.white,fontSize: 16)),
                                ],)
                          ),),
                      ],),


                  ],
                ),
              ),),



            Align(
              alignment: FractionalOffset.bottomRight,
              child: FlatButton(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Align(
                          alignment: FractionalOffset.center,
                          child:FlatButton(
                              onPressed: () {
                                _navigateToNextScreen(context);
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Text("Continue",style: TextStyle(color: Colors.white,fontSize: 16)),

                                  Icon(
                                      Icons.arrow_forward_ios,color: Colors.white)

                                ],

                              )

                          ),),

                      ],),


                  ],
                ),
              ),),

          ],),
      ),


    );
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Time()),
    );
  }
}