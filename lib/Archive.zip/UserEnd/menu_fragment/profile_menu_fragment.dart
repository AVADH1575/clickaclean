import 'dart:io';

import 'package:click_a_clean/ProviderEnd/AccountSetup/PersonalInformation/personal_information_third.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/VerifyAccount/IdentityVerificationSubmitVideo.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/VerifyAccount/verify_identity_second.dart';
import 'package:click_a_clean/UserEnd/PaymentSection/PaymentOptions.dart';
import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:click_a_clean/UserEnd/login/login_screen.dart';
import 'package:click_a_clean/UserEnd/menu_fragment/FavouriteScreen.dart';
import 'package:click_a_clean/UserEnd/menu_fragment/NotificationsHistory.dart';
import 'package:click_a_clean/UserEnd/menu_fragment/help_menu_fragment.dart';
import 'package:click_a_clean/UserEnd/menu_fragment/profile_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';



class ProfileMenu extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ProfileMenu();
  }
}
class _ProfileMenu extends State<ProfileMenu> {
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  File _image;
  void showInSnackBar(String value) {
    scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(value)));}

  @override
  void initState() {
    super.initState();
  }
  void open_camera(BuildContext context)
  async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    setState(() {
      _image = image ;
    });
    Navigator.of(context).pop();

  }
  void open_gallery(BuildContext context)
  async {
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      _image = image ;
    });
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: scaffoldKey,
      // appBar: AppBar(title: Text("Identity Verification"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),),

        body: SingleChildScrollView(

            child:
            Container(
                color: Color.fromRGBO(248, 248, 248, 1),
                child:Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        Container(
                          color: Color.fromRGBO(248, 248, 248, 1),
                          child:
                          Padding(
                            padding: EdgeInsets.fromLTRB(5, 25, 5, 0),

                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[

                                IconButton(icon: Icon(Icons.arrow_back_ios,color: Color.fromRGBO(248, 248, 248, 1),),),
                                Text("Profile",style: TextStyle(color: Color.fromRGBO(112, 112, 112, 1), fontSize: 20),),
                                IconButton(icon: Icon(Icons.notifications_none,color: Color.fromRGBO(125, 121, 204, 1))),

                              ],
                            ),),

                        ),
                        Container(
                          color: Color.fromRGBO(248, 248, 248, 1),
                          child:Row(
                            // mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Column(
                                // mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                          FlatButton(
                          child:new Stack(fit: StackFit.loose,
                              children: <Widget>[
                                new Row(
                                  //mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    new Container(
                                      width: 90.0,
                                      height: 90.0,

                                      child: _image == null ? Image.asset('assets/images/logo_img.png') : Image.file(_image),),

                                  ],
                                ),
                                Padding(
                                    padding: EdgeInsets.only(top: 60.0, left: 65.0,bottom: 15),
                                    child: new Row(

                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: <Widget>[

                                        Container(
                                          height:28,
                                          width:28,
                                          decoration:BoxDecoration(borderRadius: BorderRadius.circular(14.0),color: Color.fromRGBO(39, 180, 221, 1),),

                                          child:
                                          new Icon(
                                            Icons.edit,
                                            color: Colors.white,
                                          ),

                                        )
                                      ],
                                    )),
                              ]),onPressed: (){
                          _showChoiceDailog(context);
                        },
                        ),
          ],),
                              Align(
                                alignment: FractionalOffset.topLeft,
                                child:Padding(
                                  padding: EdgeInsets.fromLTRB(11, 0, 0, 0),

                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[

                                      Align(
                                        alignment: Alignment.topLeft,

                                        child:
                                         Text("Thompson S.",style: TextStyle(color: Color.fromRGBO(112, 112, 112, 1), fontSize: 18),textAlign: TextAlign.start,),),
                                         Text("Park Avenue Street20 , Paris , France",style: TextStyle(color: Color.fromRGBO(112, 112, 112, 1), fontSize: 13),),

                                    ],
                                  ),),
                              ),

                            ],),),
                        Container(

                          decoration: new BoxDecoration(
                              borderRadius: BorderRadius.circular(0.0),
                              color: Colors.white
                          ),
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                          child:Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[

                              Container(
                                //padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                child:
                                FlatButton(

                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                    Row(
                                   // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Icon(Icons.account_box,color: Color.fromRGBO(129, 130, 130, 1),),
                                      Padding(
                                          padding: EdgeInsets.fromLTRB(18, 0, 0, 0),
                                      child:Text(

                                          'Account Settings',
                                          style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                          textAlign: TextAlign.start
                                      )),],),

                                     // Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                    ],
                                  ),
                                  onPressed: (){
                                    _navigateToNextScreen(context);
                                  },
                                ),
                              ),
                              Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),


                              Container(
                                padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                child:
                                FlatButton(

                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Icon(Icons.favorite,color: Color.fromRGBO(129, 130, 130, 1),),
                                          Padding(
                                              padding:  EdgeInsets.fromLTRB(18, 0, 0, 0),
                                              child: Text(
                                                  'Favourites',
                                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                  textAlign: TextAlign.start
                                              )),],),
                                      new Container(
                                      ),
                                     // Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                    ],
                                  ),onPressed: (){
                                    _navigateToFavouriteScreen(context);
                                },),
                              ),

                              Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                              Container(
                                padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                child:
                                FlatButton(

                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Icon(Icons.credit_card,color: Color.fromRGBO(129, 130, 130, 1),),
                                          Padding(
                                              padding:  EdgeInsets.fromLTRB(18, 0, 0, 0),
                                              child: Text(
                                                  'Payment Options',
                                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                  textAlign: TextAlign.start
                                              )),],),
                                      new Container(
                                      ),
                                      //Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                    ],
                                  ),onPressed: (){
                                 // _navigateToPaymentScreen(context);
                                  Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
                                      builder: (context) => PaymentOptions(), maintainState: false));
                                },),
                              ),

                              Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                              Container(
                                padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                child:
                                FlatButton(

                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Icon(Icons.notifications,color: Color.fromRGBO(129, 130, 130, 1),),
                                          Padding(
                                              padding:  EdgeInsets.fromLTRB(18, 0, 0, 0),
                                              child: Text(
                                                  'Notifications',
                                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                  textAlign: TextAlign.start
                                              )),],),
                                      new Container(
                                      ),
                                      //Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                    ],
                                  ),onPressed: (){
                                    _navigateToNotificationScreen(context);
                                },),
                              ),

                              Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                              Container(
                                padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                child:
                                FlatButton(

                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Icon(Icons.chat,color: Color.fromRGBO(129, 130, 130, 1),),
                                          Padding(
                                              padding:  EdgeInsets.fromLTRB(18, 0, 0, 0),
                                              child: Text(
                                                  'Help Center',
                                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                  textAlign: TextAlign.start
                                              )),],),
                                      new Container(
                                      ),
                                      //Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                    ],
                                  ),
                                onPressed: (){
                                  _navigateToHelpScreen(context);
                                },),
                              ),
                              // Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),

                              Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                              Container(
                                padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                child:
                                FlatButton(

                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Icon(Icons.share,color: Color.fromRGBO(129, 130, 130, 1),),
                                          Padding(
                                              padding:  EdgeInsets.fromLTRB(18, 0, 0, 0),
                                              child: Text(
                                                  'Share App',
                                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                  textAlign: TextAlign.start
                                              )),],),
                                      new Container(
                                      ),
                                      //Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                    ],
                                  ),onPressed: (){
                                  scaffoldKey.currentState
                                      .showSnackBar(new SnackBar(content: new Text("Pending")));
                                },),
                              ),


                              Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                              Container(
                                padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                child:
                                FlatButton(

                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Icon(Icons.star,color: Color.fromRGBO(129, 130, 130, 1),),
                                          Padding(
                                              padding:  EdgeInsets.fromLTRB(18, 0, 0, 0),
                                              child: Text(
                                                  'Rate App on Playstore',
                                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                  textAlign: TextAlign.start
                                              )
                                          ),],),
                                      new Container(
                                      ),
                                      //Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                    ],
                                  ),onPressed: (){
                                  scaffoldKey.currentState
                                      .showSnackBar(new SnackBar(content: new Text("Pending")));
                                },),
                              ),
                              Container(height: 1),
                            ],),),

                      ],),

                    FlatButton(

                      child: Container(
                        margin: EdgeInsets.fromLTRB(0, 38, 0, 0),
                        child:

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text('Logout',style: TextStyle(
                                fontSize: 16,fontWeight: FontWeight.bold,
                                color:Color.fromRGBO(255, 0, 0, 1))),
                            //Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),

//                           Column(
//                               children: <Widget>[
//                            FlatButton(
//                              onPressed: () {},
//                              child:Icon(Icons.play_circle_filled,color: Color.fromRGBO(241, 123, 72, 1),)
//                            )],)
                          ],
                        ),

                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      textColor: Color.fromRGBO(255, 0, 0, 1),

                      //splashColor: Color.fromRGBO(0, 0, 0, 0.16),

                      onPressed: () {
                        //_navigateToNextScreen(context);
                      },
                    )


                  ],))));
  }
  Future<void> _showChoiceDailog(BuildContext context){
    return showDialog(context: context, builder : (BuildContext context){
      return AlertDialog(
        title: Text("Make a Choice!",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w300),textAlign: TextAlign.center,),
        content: SingleChildScrollView(
          child: ListBody(

            children: <Widget>[
              Align(
                alignment: Alignment.center,
                child:GestureDetector(

                  child: Row(

                    //mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                      Icon(Icons.photo_library),
                      Padding(
                          padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
                          child:Text("Gallery",style: TextStyle(fontSize: 14),)
                      ),
                    ],),

                  onTap: (){
                    open_gallery(context);
                  },
                ),),
              Align(
                alignment: Alignment.center,
                child:Padding(
                    padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                    child:GestureDetector(
                      child:Row(
                        //  mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[

                          Icon(Icons.camera),
                          Padding(
                              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
                              child:Text("Camera",style: TextStyle(fontSize: 14),)
                          ),
                        ],),
                      onTap: (){
                        open_camera(context);
                      },
                    )
                ),),

            ],
          ),
        ),
      );
    });
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ProfilePage()),
    );
  }
  void _navigateToHelpScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Help_Menu()),
    );
  }
  void _navigateToNotificationScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NotificationHistoryScreen()),
    );
  }
  void _navigateToFavouriteScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => FavouriteHistoryScreen()),
    );
  }
  void _navigateToPaymentScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => PaymentOptions()),
    );
  }


}