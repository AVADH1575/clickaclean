import 'dart:io';

import 'package:click_a_clean/UserEnd/menu_fragment/booking_history/booking_time.dart';

import 'package:flutter/material.dart';

class CarVelter extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

      return MaterialApp(
      home: Scaffold(
        body: SafeArea(

        child:SingleChildScrollView(


          child:Flex(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
            direction: Axis.vertical,
            children: <Widget>[

             Container(

              child: Flex(
//                shrinkWrap:true,
//                scrollDirection: Axis.vertical,
              direction: Axis.vertical,
                children: <Widget>[

                  Container(
                    height: 70,
                    color: Color.fromRGBO(125, 121, 204, 1),
                    child: Column(

                      children: [
                        SizedBox(height: 20.0,),
                        Text('Car Clean',
                          style: TextStyle(
                              decoration: TextDecoration.none,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                              fontSize: 16),
                        ),
                        SizedBox(height: 5.0,),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Padding(
                              padding: EdgeInsets.only(left: 20.0, right: 10.0),
                              child: Container(
                                  height: 20,
                                  width: 20,

                                  alignment: Alignment.topLeft,
                                  decoration: new BoxDecoration(
                                      image: new DecorationImage(
                                        image: new AssetImage('assets/images/location_icon_white.png'),
                                        fit: BoxFit.fill,
                                      )
                                  )

                              ),),

                            Text(
                              'Park Avenue Street17 , Paris , France',
                              style: TextStyle(
                                  decoration: TextDecoration.none,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16),
                            )

                          ],),],),),
                  SizedBox(height: 20.0,),
                  Container(
                      alignment: Alignment.topLeft,
                      margin: new EdgeInsets.symmetric(horizontal: 20.0),
                      child:
                      Text("CAR TYPE",textAlign: TextAlign.left)

                  ),
                  SizedBox(height: 10.0,),
                  Container(
                    height: 120,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: <Widget>[
                        Container(
                            width: 132,
                            color: Color(0xFFeaeaea),
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Container(
                                      width:84,
                                      height: 25,
                                      alignment: Alignment.center,

                                      decoration: new BoxDecoration(
                                          image: new DecorationImage(
                                              image: new AssetImage('assets/images/car.png'),
                                              fit: BoxFit.fill
                                          )
                                      )

                                  ),
                                  Text("CAR"),
                                  Container(
                                      width:20,
                                      height: 20,
                                      alignment: Alignment.topRight,

                                      decoration: new BoxDecoration(
                                          image: new DecorationImage(
                                              image: new AssetImage('assets/images/selected_icon.png'),
                                              fit: BoxFit.fill
                                          )
                                      )

                                  ),
                                ]
                            )

                        ),
                        Container(
                            width: 132,
                            color: Colors.white30,
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Container(
                                      width:82,
                                      height: 37,
                                      alignment: Alignment.center,

                                      decoration: new BoxDecoration(
                                          image: new DecorationImage(
                                              image: new AssetImage('assets/images/van.png'),
                                              fit: BoxFit.fill
                                          )
                                      )

                                  ),
                                  Text("VAN")

                                ]
                            )
                        ),
                        Container(
                            width: 132,
                            color: Color(0xFFeaeaea),
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Container(
                                      width:84,
                                      height: 32,
                                      alignment: Alignment.center,

                                      decoration: new BoxDecoration(
                                          image: new DecorationImage(
                                              image: new AssetImage('assets/images/car_three.png'),
                                              fit: BoxFit.fill
                                          )
                                      )

                                  ),
                                  Text("4X4")
                                  ,

                                  Container(
                                      width:20,
                                      height: 20,
                                      alignment: Alignment.topRight,

                                      decoration: new BoxDecoration(
                                          image: new DecorationImage(
                                              image: new AssetImage('assets/images/selected_icon.png'),
                                              fit: BoxFit.fill
                                          )
                                      )

                                  ),
                                ]
                            )
                        ),

                      ],
                    ),
                  ),
                  SizedBox(height: 10.0,),
                  Padding(
                    padding: EdgeInsets.only(left: 8.0,right: 8.0),
                    child:Container(
                      height: 195,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("assets/images/car-bg.png"), fit: BoxFit.cover)),
                      child: Column(

                        children: [

                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(top: 65.0, left: 20.0,right: 70),


                                child:Text(
                                  'TYPES OF \n VALETER',
                                  style: TextStyle(
                                      decoration: TextDecoration.none,
                                      color: Colors.white,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 23),
                                ),),



                            ],),],),),),
                  SizedBox(height: 10.0,),
                  Container(
                    padding: EdgeInsets.only(left: 8.0,right: 8.0),
                    height: 165,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(right: 8.0),
                          child:Container(
                              width: 140,
                              color: Color(0xFFeaeaea),
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text("Valet 1"),
                                    SizedBox(height: 10.0,),
                                    Text("Valet 1 Hand Car \n Wash and Dry,\n Tyres Dressed"),
                                    SizedBox(height: 10.0,),
                                    Container(
                                        width:20,
                                        height: 20,
                                        alignment: Alignment.center,

                                        decoration: new BoxDecoration(
                                            image: new DecorationImage(
                                                image: new AssetImage('assets/images/selected_icon.png'),
                                                fit: BoxFit.fill
                                            )
                                        )

                                    ),


                                  ]
                              )
                          ),),
                        Padding(
                          padding: EdgeInsets.only(right: 8.0),
                          child:Container(
                              width: 140,
                              color: Color(0xFFeaeaea),
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text("Valet 1"),
                                    SizedBox(height: 10.0,),
                                    Text("Valet 1 Hand Car \n Wash and Dry,\n Tyres Dressed"),
                                    SizedBox(height: 10.0,),
                                    Container(
                                        width:20,
                                        height: 20,
                                        alignment: Alignment.center,

                                        decoration: new BoxDecoration(
                                            image: new DecorationImage(
                                                image: new AssetImage('assets/images/selected_icon.png'),
                                                fit: BoxFit.fill
                                            )
                                        )

                                    ),


                                  ]
                              )
                          ),),
                        Container(
                            width: 140,
                            color: Colors.white,
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text("Valet 1"),
                                  SizedBox(height: 10.0,),
                                  Text("Valet 1 Hand Car \n Wash and Dry,\n Tyres Dressed"),
                                  SizedBox(height: 10.0,),



                                ]
                            )

                        ),



                      ],
                    ),
                  ),



             SizedBox(height:50)


                ],
              ),
            ),

//              Align(
//                alignment: Alignment.center,
//
//                child:Container(
//
//                  color: Color.fromRGBO(125, 121, 204, 1),
//                  height: 52,
//
//                  child: Row(
//                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                    children: <Widget>[
//
//
//                      Align(
//                        alignment: FractionalOffset.bottomLeft,
//                        child: FlatButton(
//                          child: Row(
//                            mainAxisAlignment: MainAxisAlignment.start,
//                            crossAxisAlignment: CrossAxisAlignment.start,
//                            children: <Widget>[
//                              Row(
//                                mainAxisAlignment: MainAxisAlignment.start,
//                                crossAxisAlignment: CrossAxisAlignment.start,
//                                children: <Widget>[
//                                  Align(
//                                    alignment: FractionalOffset.centerLeft,
//                                    child:FlatButton(
//                                        onPressed: () {},
//                                        child: Row(
//                                          mainAxisAlignment: MainAxisAlignment.start,
//                                          crossAxisAlignment: CrossAxisAlignment.start,
//                                          children: <Widget>[
//
//                                            Text("\$ 400",style: TextStyle(color: Colors.white,fontSize: 16)),
//                                          ],)
//                                    ),),
//                                ],),
//
//
//                            ],
//                          ),
//                        ),),
//
//
//
//                      Align(
//                        alignment: FractionalOffset.bottomRight,
//                        child: FlatButton(
//                          child: Row(
//                            mainAxisAlignment: MainAxisAlignment.center,
//                            crossAxisAlignment: CrossAxisAlignment.center,
//                            children: <Widget>[
//                              Row(
//                                mainAxisAlignment: MainAxisAlignment.center,
//                                crossAxisAlignment: CrossAxisAlignment.center,
//                                children: <Widget>[
//                                  Align(
//                                    alignment: FractionalOffset.center,
//                                    child:FlatButton(
// onPressed: () {
// _navigateToNextScreen(context);
// },
//                                        child: Row(
//                                          mainAxisAlignment: MainAxisAlignment.center,
//                                          crossAxisAlignment: CrossAxisAlignment.center,
//                                          children: <Widget>[
//                                            Text("Continue",style: TextStyle(color: Colors.white,fontSize: 16)),
//
//                                            Icon(
//                                                Icons.arrow_forward_ios,color: Colors.white)
//
//                                          ],
//
//                                        )
//
//                                    ),),
//
//                                ],),
//
//
//                            ],
//                          ),
//                        ),),
//
//                    ],),
//                ),)

]

        ))),
        bottomNavigationBar: new Container(

            color: Color.fromRGBO(125, 121, 204, 1),
            height: 52,

            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[


                Align(
                  alignment: FractionalOffset.bottomLeft,
                  child: FlatButton(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Align(
                              alignment: FractionalOffset.centerLeft,
                              child:FlatButton(
                                  onPressed: () {},
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[

                                      Text("\$ 400",style: TextStyle(color: Colors.white,fontSize: 16)),
                                    ],)
                              ),),
                          ],),


                      ],
                    ),
                  ),),



                Align(
                  alignment: FractionalOffset.bottomRight,
                  child: FlatButton(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Align(
                              alignment: FractionalOffset.center,
                              child:FlatButton(
                                  onPressed: () {
                                    _navigateToNextScreen(context);
                                  },
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Text("Continue",style: TextStyle(color: Colors.white,fontSize: 16)),

                                      Icon(
                                          Icons.arrow_forward_ios,color: Colors.white)

                                    ],

                                  )

                              ),),

                          ],),


                      ],
                    ),
                  ),),

              ],),
          ),
      ),
    );

    _body(){

    }

  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BookingTime()),
    );
  }
}