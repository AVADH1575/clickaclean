import 'package:click_a_clean/UserEnd/menu_fragment/booking_history/booking_time.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';

class DomesticCleaner extends StatefulWidget {
  DomesticCleaner() : super();
  @override

  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _DomesticCleaner();
  }
}

class _DomesticCleaner extends State<DomesticCleaner> {

  int _radioValue1 = -1;
  int correctScore = 0;
  int _radioValue2 = -1;
  int _radioValue3 = -1;
  int _radioValue4 = -1;
  int _radioValue5 = -1;
  String _mySelection;


  Map building_data;
  Map size_data;
  Map room_size_data;

  List building_type_data;
  List select_size_data;
  List room_select_size_data;

  bool a = true;
  bool _visible = false;

  Future getBuildingData() async {

    http.Response response =  await http.get("http://sharpwebstudio.us/clickaclean/api/user/houses", headers: {
      'x-api-key': 'boguskey',
    });
    //await http.get("http://sharpwebstudio.us/clickaclean/api/user/countries");

    building_data = json.decode(response.body);
    setState(() {
      building_type_data = building_data["data"];
      print("===country data==="+building_type_data.toString());
    });

  }

  Future getSizeListData() async {

    http.Response response =  await http.get("http://sharpwebstudio.us/clickaclean/api/user/houseSize", headers: {
      'x-api-key': 'boguskey',
    });
    //await http.get("http://sharpwebstudio.us/clickaclean/api/user/countries");

    size_data = json.decode(response.body);
    setState(() {
      select_size_data = size_data["data"];
      print("===country data==="+select_size_data.toString());
    });

  }
  Future getRoomSizeData() async {

    http.Response response =  await http.get("http://sharpwebstudio.us/clickaclean/api/user/NoRooms", headers: {
      'x-api-key': 'boguskey',
    });
    //await http.get("http://sharpwebstudio.us/clickaclean/api/user/countries");

    room_size_data = json.decode(response.body);
    setState(() {
      room_select_size_data = room_size_data["data"];
      print("===country data==="+room_select_size_data.toString());
    });

  }
  bool viewVisible = false ;

  void showWidget(){
    setState(() {
      viewVisible = true ;
    });
  }

  void hideWidget(){
    setState(() {
      viewVisible = false ;
    });
  }
  @override
  void initState() {
    super.initState();

    getBuildingData();
    getSizeListData();

  }

  int _currentIndex ;
  bool _isEnabled = true;

  _onChanged() {
    setState(() {
      _isEnabled = !_isEnabled;
    });
  }


  void _handleRadioValueChange1(int value) {
    setState(() {
      _radioValue1 = value;

      switch (_radioValue1) {
        case 0:
       //   Fluttertoast.showToast(msg: 'Correct !',toastLength: Toast.LENGTH_SHORT);
          correctScore++;
          break;
        case 1:
         // Fluttertoast.showToast(msg: 'Try again !',toastLength: Toast.LENGTH_SHORT);
          break;
        case 2:
         // Fluttertoast.showToast(msg: 'Try again !',toastLength: Toast.LENGTH_SHORT);
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    String radioItem = '';
    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
        child:SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                children: <Widget>[
               Column(
          children: <Widget>[

                  Container(

                    height: 70,
                    color: Color.fromRGBO(125, 121, 204, 1),
                    child: Column(

                      children: [

                        SizedBox(height: 20.0,),


                        Text('Domestic Clean',
                          style: TextStyle(
                              decoration: TextDecoration.none,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                              fontSize: 16),

                        ),

                        SizedBox(height: 5.0,),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Padding(
                              padding: EdgeInsets.only(left: 20.0, right: 10.0),
                              child: Container(
                                  height: 20,
                                  width: 20,

                                  alignment: Alignment.topLeft,
                                  decoration: new BoxDecoration(
                                      image: new DecorationImage(
                                        image: new AssetImage('assets/images/location_icon_white.png'),
                                        fit: BoxFit.fill,
                                      )
                                  )

                              ),),

                            Text(
                              'Park Avenue Street17 , Paris , France',
                              style: TextStyle(
                                  decoration: TextDecoration.none,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16),
                            )

                          ],),],),),
                  SizedBox(height: 20.0,),
                  Container(
                      alignment: Alignment.topLeft,
                      margin: new EdgeInsets.symmetric(horizontal: 20.0),
                      child:
                      Text("BUILDING TYPES",textAlign: TextAlign.left)

                  ),


            new GridView.builder(
              shrinkWrap: true,
              itemCount: building_type_data == null ? 0 : building_type_data.length,

              padding: const EdgeInsets.only(left:20.0,right: 20,top: 10),

              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisSpacing: 0,
                  mainAxisSpacing: 20,
                  crossAxisCount: 3),
              itemBuilder: (BuildContext context, int index) {
                return GestureDetector(

                    onTap: () {
                      //showWidget(userData[index]['id']);
                      _navigateToNextScreen(context);
                      // _navigateToNextScreen(context,userData[index]['id'].toString());
                      print("${building_type_data[index]['id'].toString()}");
                    },
                    child:Container(

                      child: Padding(
                        padding: const EdgeInsets.all(0.0),

                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Column(
                                children:<Widget>[
//                  CircleAvatar(
//                    backgroundImage: NetworkImage(userData[index]["building_img"]),
//                  ),
                                  Image.network(building_type_data[index]["building_img"],height: 85,width: 90,),
                                  Container(
                                      padding: const EdgeInsets.only(left:8.0),
                                      child: Container(

                                        child: Text("${building_type_data[index]["name"]}",
                                          style: TextStyle(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w700,
                                          ),),
                                      ))]),

//                  Visibility(
//                      maintainSize: true,
//                      maintainAnimation: true,
//                      maintainState: true,
//                      visible: viewVisible,
//                      child: Container(
//                          height: 16,
//                          width: 16,
//                          color: Colors.green,
//                          margin: EdgeInsets.only(top: 10, bottom: 10),
//                          child: Center(child: Text('Show ',
//                              textAlign: TextAlign.center,
//                              style: TextStyle(color: Colors.white,
//                                  fontSize: 10)))
//                      )
//                  ),

                          ],
                        ),
                      ),
                    ));

              },
            ),




          Padding(
            padding: EdgeInsets.only(top:8.0, left: 10.0,right: 10),
            child:IntrinsicHeight(
              child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Expanded(
                  child: Column(children: [

                    Container(height: 42.0, color: Colors.transparent,

                      child: Container(

                        decoration: new BoxDecoration(
                            borderRadius: BorderRadius.circular(8.0),
                            border: Border.all(color: Color.fromRGBO(218, 218, 218, 1)),
                          color: Color.fromRGBO(229, 233, 255, 1),
                        ),



                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.only(left: 8.0,top: 8.0,bottom: 8.0),
                              child: Text(
                                'Select Size',style: TextStyle(
                                fontSize: 15,
                              ),
                              ),
                            ),
                            DropdownButton(
                              isDense: true,
                              hint: new Text(""),
                              value: _mySelection,
                              onChanged: (String newValue) {

                                setState(() {
                                  _mySelection = newValue;
                                });
                                print (_mySelection);
                              },
                              items: select_size_data.map((map) {

                                return new DropdownMenuItem(
                                  value: map["id"].toString(),
                                  child: new Text(
                                    map["size"],
                                  ),
                                );
                              }).toList(),
                            ),


                          ],
                        ),

                      ),
                    ),
                  ]),
                ),
                SizedBox(width: 5,),
                Expanded(child: Container(height: 42.0,color: Colors.transparent,  child: Container(

                  decoration: new BoxDecoration(
                    borderRadius: BorderRadius.circular(8.0),
                    border: Border.all(color: Color.fromRGBO(218, 218, 218, 1)),
                    color: Color.fromRGBO(229, 233, 255, 1),
                  ),


                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[

                      Container(
                        padding: EdgeInsets.only(left: 8.0,top: 8.0,bottom: 8.0),
                        child: Text(
                          'No. of Room',style: TextStyle(
                          fontSize: 15,
                        ),
                        ),
                      ),
                      new DropdownButton<String>(

                        items: <String>['1', '2', '3','4','5'].map((String value) {
                          return new DropdownMenuItem<String>(
                            value: value,
                            child: new Text(value),
                          );
                        }).toList(),
                        onChanged: (_) {},
                      ),
                    ],
                  ),
                ),


                )),
              ]),
            ),),


                  Padding(
                    padding: EdgeInsets.only(left: 8.0,right: 8.0,top: 8,bottom: 10),
                    child:Container(
                      height: 195,
                      decoration: new BoxDecoration(
                          image: new DecorationImage(
                            image: new AssetImage('assets/images/dog-bg.png'),
                            fit: BoxFit.fill,
                          )
                      ),
                      child: Column(

                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(top:65.0, left: 20.0,right: 70),
                                child:Text(
                                  'Do you \n Love Pets?',
                                  style: TextStyle(
                                      decoration: TextDecoration.none,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 23),
                                ),),
//                              new Row(
//                                crossAxisAlignment: CrossAxisAlignment.center,
//                                       children: <Widget>[
//
//                                    Radio(
//                                      groupValue: radioItem,
//                                      //title: Text('Radio Button Item 1'),
//                                      value: 'Item 1',
//                                      onChanged: (val) {
//                                        setState(() {
//                                          radioItem = val;
//                                        });
//                                      },
//                                    ),
//
//                                    Radio(
//                                      groupValue: radioItem,
//                                      //title: Text('Radio Button Item 2'),
//                                      value: 'Item 2',
//                                      onChanged: (val) {
//                                        setState(() {
//                                          radioItem = val;
//                                        });
//                                      },
//                                    ),
//
//                                    Text('$radioItem', style: TextStyle(fontSize: 23),)
//
//
//                                ],
//                              ),

/////
                              new Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  new Container(
                                    padding: EdgeInsets.all(0.0),
                                    child: new Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: <Widget>[


                                          new Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: <Widget>[
                                              new Radio(
                                                value: 0,
                                      groupValue: _currentIndex,

                                      onChanged: _isEnabled
                                          ? (val) {
                                        setState(() {
                                          _currentIndex = val;
                                          showWidget();
                                        });
                                      }
                                          : null,
                                    ),





                                              new Text(
                                                'Yes',
                                                style: new TextStyle(fontSize: 16.0),
                                              ),
                                              new Radio(
                                                value: 1,
                                                groupValue: _currentIndex,

                                                onChanged: _isEnabled
                                                    ? (val) {
                                                  setState(() {
                                                    _currentIndex = val;
                                                    showWidget();
                                                  });
                                                }
                                                    : null,
                                              ),
                                              new Text(
                                                'No',
                                                style: new TextStyle(
                                                  fontSize: 16.0,
                                                ),
                                              ),

                                            ],
                                          ),



                                        ]),),


                                ],),




                            ////
                            ],),],),),),


],),







                ],
              ),),



          ),
        bottomNavigationBar:  Visibility(
    visible: viewVisible,
       child: new Container(

          color: Color.fromRGBO(125, 121, 204, 1),
          height: 52,

          child: Row(

            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[


              Align(
                alignment: FractionalOffset.bottomLeft,
                child: FlatButton(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Align(
                            alignment: FractionalOffset.centerLeft,
                            child:FlatButton(
                                onPressed: () {},
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[

                                    Text("\$ 400",style: TextStyle(color: Colors.white,fontSize: 16)),
                                  ],)
                            ),),
                        ],),


                    ],
                  ),
                ),),



              Align(
                alignment: FractionalOffset.bottomRight,
                child: FlatButton(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Align(
                            alignment: FractionalOffset.center,
                            child:FlatButton(
                                onPressed: () {
                                  _navigateToNextScreen(context);
                                },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text("Continue",style: TextStyle(color: Colors.white,fontSize: 16)),

                                    Icon(
                                        Icons.arrow_forward_ios,color: Colors.white)

                                  ],

                                )

                            ),),

                        ],),


                    ],
                  ),
                ),),

            ],),
        ),
        ),
      ),

    );
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BookingTime()),
    );
  }

}
