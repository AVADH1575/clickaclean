import 'package:click_a_clean/UserEnd/PaymentSection/Payment.dart';
import 'package:click_a_clean/UserEnd/menu_fragment/home_menu_fragment.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TrackOrder extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
// TODO: implement createState

    return _TrackOrder();
  }
}

class _TrackOrder extends State<TrackOrder> {
  bool monVal = false;
  bool tuVal = false;
  bool wedVal = false;
  bool thuVal = false;
  @override
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  File _image;
  void showInSnackBar(String value) {
    scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(value)));}

  @override
  void initState() {
    super.initState();
  }
  void open_camera(BuildContext context)
  async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    setState(() {
      _image = image ;
    });
    Navigator.of(context).pop();

  }
  void open_gallery(BuildContext context)
  async {
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      _image = image ;
    });
    Navigator.of(context).pop();
  }




  int _radioValue1 = -1;
  int correctScore = 0;
  int _radioValue2 = -1;
  int _radioValue3 = -1;
  int _radioValue4 = -1;
  int _radioValue5 = -1;

  void _handleRadioValueChange1(int value) {
    setState(() {
      _radioValue1 = value;

      switch (_radioValue1) {
        case 0:
// Fluttertoast.showToast(msg: 'Correct !',toastLength: Toast.LENGTH_SHORT);
          correctScore++;
          break;
        case 1:
// Fluttertoast.showToast(msg: 'Try again !',toastLength: Toast.LENGTH_SHORT);
          break;
        case 2:
// Fluttertoast.showToast(msg: 'Try again !',toastLength: Toast.LENGTH_SHORT);
          break;
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(125, 121, 204, 1),
        title: Text('Car Clean'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(

        child:Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Column(
              children: <Widget>[

                Container(
                  height: 200,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage("assets/images/map-new.png"),fit: BoxFit.fill)),


                ),
new Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: <Widget>[
                new Container(
                  color: Color.fromRGBO(248, 248, 248, 1),
                  child:Row(

                    children: <Widget>[
                      Column(
                        // mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          FlatButton(
                            child:new Stack(fit: StackFit.loose,
                                children: <Widget>[
                                  new Row(
                                    //mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      new Container(
                                        width: 70.0,
                                        height: 70.0,

                                        child: _image == null ? Image.asset('assets/images/logo_img.png') : Image.file(_image),),

                                    ],
                                  ),

                                ]),onPressed: (){

                          },
                          ),
                        ],),
                     Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                       children: <Widget>[
                      Align(

                        alignment: FractionalOffset.topLeft,
                        child:Padding(
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 0),

                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Align(
                                alignment: Alignment.topLeft,

                                child:
                                Text("Your car cleaner",style: TextStyle(color: Color.fromRGBO(176, 175, 175, 1), fontSize: 9),textAlign: TextAlign.start,),),

                              Align(
                                alignment: Alignment.topLeft,

                          child:
                                Text("Thompson S.",style: TextStyle(color: Color.fromRGBO(112, 112, 112, 1), fontSize: 14),textAlign: TextAlign.start,),),
                             new Row(
                                 children: <Widget>[
                              Icon(Icons.star,color: Colors.yellow),
                                   Icon(Icons.star,color: Colors.yellow),

                                   Icon(Icons.star_half,color: Colors.yellow),
                          ]
                             )
                            ],
                          ),),
                      ),
                    ],),
                      Container(
                        color: Color.fromRGBO(248, 248, 248, 1),
                        padding: EdgeInsets.only(left: 30),
                        child:Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Column(
                              // mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                FlatButton(
                                  child:new Stack(fit: StackFit.loose,
                                      children: <Widget>[
                                        new Row(
                                          //mainAxisAlignment: MainAxisAlignment.center,
                                          children: <Widget>[
                                            IconButton(
                                              icon: new Icon(Icons.favorite, color: Color.fromRGBO(112, 112, 112, 1)),

                                              onPressed: () {},
                                            ),
                                            IconButton(
                                              icon: new Icon(Icons.phone, color: Color.fromRGBO(125, 121, 204, 1)),

                                              onPressed: () {},
                                            ),
                                          ],
                                        ),

                                      ]),onPressed: (){

                                },
                                ),
                              ],),


                          ],),)
                    ],),),

],),
                Divider(color:Colors.grey,height:1),
                new Container(
                  child:Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.fromLTRB(25, 10, 0, 10),
                        child:Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Your Selected Item Details',
                            style: TextStyle(fontSize:14,color: Color.fromRGBO(81, 92, 111, 1,)),

                          ),
                        ),),
                    ],
                  ),
                ),
                new Container(
padding: EdgeInsets.only(left:10,right: 10),
                  child: Card(

                    color: Color.fromRGBO(242, 242, 242, 10),

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),

                    child: Column(

                      children: [

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(

                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [

                        Padding(
                          padding: EdgeInsets.fromLTRB(10, 15, 0, 0),
                          child:Align(
                            alignment: FractionalOffset.topLeft,
                            child: Text(
                              'Car Valeter',
                              style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1).withOpacity(0.7),fontSize: 13),

                            ),
                          ),),

                        Container(


                          child: Row(
                            children: <Widget>[

                              Padding(
                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                  child:Row(

//mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    children: <Widget>[

                                      Checkbox(
                                        checkColor: Color.fromRGBO(241, 123, 72, 1) ,
                                        focusColor: Color.fromRGBO(241, 123, 72, 1),
                                        activeColor: Colors.white,
                                        hoverColor: Color.fromRGBO(96, 96, 96, 1),
                                        value: monVal,
                                        onChanged: (bool value) {
                                          setState(() {
                                            monVal = value;
                                          });
                                        },
                                      ),
                                      Padding(
                                          padding: EdgeInsets.fromLTRB(0, 5, 10, 0),
                                          child:
                                          Text("Car",
                                            style: TextStyle(color: Color.fromRGBO(96, 96, 96, 1) ,fontSize: 12),textAlign: TextAlign.justify,)
                                      ),
                                      Checkbox(
                                        checkColor: Color.fromRGBO(241, 123, 72, 1) ,
                                        focusColor: Color.fromRGBO(241, 123, 72, 1),
                                        activeColor: Colors.white,
                                        hoverColor: Color.fromRGBO(96, 96, 96, 1),
                                        value:tuVal,
                                        onChanged: (bool value) {
                                          setState(() {
                                            tuVal = value;
                                          });
                                        },
                                      ),
                                      Padding(
                                          padding: EdgeInsets.fromLTRB(0, 5, 23, 0),
                                          child:
                                          Text("4X4",
                                            style: TextStyle(color: Color.fromRGBO(96, 96, 96, 1) ,fontSize: 12),textAlign: TextAlign.justify,)
                                      ),
                                    ],
                                  )
                              )


                            ],
                          ),
                        ),]),

                              Padding(
                                padding: EdgeInsets.fromLTRB(0, 15, 15, 0),
                              child:Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                 Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                  Column(

                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Padding(
                                        padding: EdgeInsets.fromLTRB(0, 0, 15, 0),

                                    child:
                                    Text("Data",style: TextStyle(color: Color.fromRGBO(125, 121, 204, 1), fontSize:10),textAlign: TextAlign.start,),),

                                  Padding(
                                    padding: EdgeInsets.fromLTRB(0, 3, 15, 0),

                                    child:
                                    Text("Time",style: TextStyle(color: Color.fromRGBO(125, 121, 204, 1), fontSize: 10),textAlign: TextAlign.start,),),


                                    ]), Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: <Widget>[

                                            Padding(
                                              padding: EdgeInsets.fromLTRB(0, 0, 15, 0),
                                              child:
                                              Text("22/9/20",style: TextStyle(color: Color.fromRGBO(125, 121, 204, 1), fontSize:10),textAlign: TextAlign.start,),),

                                            Padding(
                                              padding: EdgeInsets.fromLTRB(0, 3, 15, 0),
                                              child:
                                              Text("10.00am",style: TextStyle(color: Color.fromRGBO(125, 121, 204, 1), fontSize:10),textAlign: TextAlign.start,),),

                                          ])
                                    ]),
                                ],
                              ),)
                        ]),
                        Padding(
                          padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
                          child:Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Valeter Type',
                              style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1).withOpacity(0.7),fontSize: 13),

                            ),
                          ),),
                        Container(

                          child: Row(

                            children: <Widget>[

                              Padding(
                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                  child:Row(

//mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    children: <Widget>[

                                      Checkbox(
                                        checkColor: Color.fromRGBO(241, 123, 72, 1) ,
                                        focusColor: Color.fromRGBO(241, 123, 72, 1),
                                        activeColor: Colors.white,
                                        hoverColor: Color.fromRGBO(96, 96, 96, 1),
                                        value: wedVal,
                                        onChanged: (bool value) {
                                          setState(() {
                                            wedVal = value;
                                          });
                                        },
                                      ),
                                      Padding(
                                          padding: EdgeInsets.fromLTRB(0, 5, 10, 0),
                                          child:
                                          Text("Valeter1",
                                            style: TextStyle(color: Color.fromRGBO(96, 96, 96, 1) ,fontSize: 12),textAlign: TextAlign.justify,)
                                      ),
                                      Checkbox(
                                        checkColor: Color.fromRGBO(241, 123, 72, 1) ,
                                        focusColor: Color.fromRGBO(241, 123, 72, 1),
                                        activeColor: Colors.white,
                                        hoverColor: Color.fromRGBO(96, 96, 96, 1),
                                        value:thuVal,
                                        onChanged: (bool value) {
                                          setState(() {
                                            thuVal = value;
                                          });
                                        },
                                      ),
                                      Padding(
                                          padding: EdgeInsets.fromLTRB(0, 5, 23, 0),
                                          child:
                                          Text("Valeter2",
                                            style: TextStyle(color: Color.fromRGBO(96, 96, 96, 1) ,fontSize: 12),textAlign: TextAlign.justify,)
                                      ),
                                    ],
                                  )
                              )

                            ],
                          ),
                        ),
                       Padding(
                         padding: EdgeInsets.only(top:8),
                        child:Divider(color:Colors.grey,height:1),),
                        Container(

                          child: Row(
                           mainAxisAlignment: MainAxisAlignment.spaceBetween,

                            children: [
                          Padding(
                          padding: EdgeInsets.only(left:10),
                          child:
                              Text(
                                  'Total ',
                                  style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                  textAlign: TextAlign.start
                              ),),
                              new Container(
                                alignment: Alignment.centerRight,
                                height:40,
                                width:120,
                                padding: EdgeInsets.only(left:20.0),
                                child:Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    Expanded(
                                      child: Container(
                                        child: Container(
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                                            children: <Widget>[
                                              Container(
                                                padding: EdgeInsets.only(left: 8.0,top: 8.0,bottom: 8.0),
                                                child:   Text(
                                                    '\$ 400 ',
                                                    style: TextStyle(color: new Color(0xFF7D79CC),fontSize: 15),
                                                    textAlign: TextAlign.start
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
                new Container(
                  child:Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.fromLTRB(25, 10, 0, 10),
                        child:Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Tracking History',
                            style: TextStyle(color: Colors.black,fontSize: 17),

                          ),
                        ),),
                    ],
                  ),
                ),
                new Container(

                  child: Card(


                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,

                      children: [

                        Container(
                          padding: EdgeInsets.all(40.0),

                          child: Text("No History",textAlign: TextAlign.center,),

                        ),



                      ],
                    ),
                  ),
                ),
              ],),



          ],

        ),),
      bottomNavigationBar: new Container(

        color: Color.fromRGBO(125, 121, 204, 1),
        height: 52,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[

            Align(
              alignment: FractionalOffset.bottomCenter,
              child: FlatButton(
                child:Align(
                  alignment: FractionalOffset.center,
                ),
              ),),

            Align(
              alignment: FractionalOffset.bottomCenter,
              child: FlatButton(
                child:Align(
                  alignment: FractionalOffset.center,
                  child: Text(
                    "Save Address",style: TextStyle(color: Colors.white,fontSize: 18),textAlign: TextAlign.center,
                  ),),onPressed: (){
                _navigateToNextScreen(context);
              },
              )
              ,),
            Align(
              alignment: FractionalOffset.bottomCenter,
              child: FlatButton(
                child:Align(
                  alignment: FractionalOffset.center,
                ),
              ),),
          ],),
      ),



    );
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Payment()),
    );
  }

}
