import 'package:click_a_clean/UserEnd/PaymentSection/Payment.dart';
import 'package:click_a_clean/UserEnd/menu_fragment/home_menu_fragment.dart';



import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NewAddress extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
// TODO: implement createState
    return _NewAddress();
  }
}

class _NewAddress extends State<NewAddress> {

  int _radioValue1 = -1;
  int correctScore = 0;
  int _radioValue2 = -1;
  int _radioValue3 = -1;
  int _radioValue4 = -1;
  int _radioValue5 = -1;

  void _handleRadioValueChange1(int value) {
    setState(() {
      _radioValue1 = value;

      switch (_radioValue1) {
        case 0:
// Fluttertoast.showToast(msg: 'Correct !',toastLength: Toast.LENGTH_SHORT);
          correctScore++;
          break;
        case 1:
// Fluttertoast.showToast(msg: 'Try again !',toastLength: Toast.LENGTH_SHORT);
          break;
        case 2:
// Fluttertoast.showToast(msg: 'Try again !',toastLength: Toast.LENGTH_SHORT);
          break;
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(125, 121, 204, 1),
        title: Text('Car Clean'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(

      child:Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Column(
            children: <Widget>[

              Container(
                height: 200,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/images/map-new.png"),fit: BoxFit.fill)),


              ),


              new Container(
                color: Color(0xffFFFFFF),
                child: Padding(
                  padding: EdgeInsets.only(bottom: 0.0),
                  child: new Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.only(
                              left: 25.0, right: 25.0, top: 15.0),
                          child: new Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              new Column(

                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[

                                  new Text(

                                    'Your Location',
                                    style: TextStyle(

                                        fontSize: 15.0,

                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                              new Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[

                                  new Text(

                                    'CHANGE',
                                    style: TextStyle(

                                        fontSize: 13.0,
                                        color:Color.fromRGBO(125, 121, 204, 1),
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              )
                            ],
                          )),

                      Padding(
                          padding: EdgeInsets.only(
                              left: 25.0, right: 25.0, top: 0.0),

                          child: new Row(
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              new Flexible(

                                child: new TextField(

                                  decoration: const InputDecoration(
                                    hintText: "Park Avenue Street17 , Paris , France",
                                  ),
// enabled: !_status,
// autofocus: !_status,

                                ),
                              ),
                            ],
                          )),

                      Padding(
                          padding: EdgeInsets.only(
                              left: 25.0, right: 25.0, top: 0.0),
                          child: new Row(
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              new Flexible(
                                child: new TextField(
                                  decoration: const InputDecoration(
                                      hintText: "Flat / Building / Street"),
//enabled: !_status,
                                ),
                              ),
                            ],
                          )),

                      Padding(
                          padding: EdgeInsets.only(
                              left: 25.0, right: 25.0, top: 0.0),
                          child: new Row(
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              new Flexible(
                                child: new TextField(
                                  decoration: const InputDecoration(
                                      hintText: "Your Name"),
// enabled: !_status,
                                ),
                              ),
                            ],
                          )),
                      Padding(
                          padding: EdgeInsets.only(
                              left: 25.0, right: 25.0, top: 0.0),
                          child: new Row(
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              new Flexible(
                                child: new TextField(
                                  decoration: const InputDecoration(
                                      hintText: "Phone Number (Optional)"),
// enabled: !_status,
                                ),
                              ),
                            ],
                          )),
                      Padding(
                          padding: EdgeInsets.only(
                              left: 25.0, right: 25.0, top: 0.0),
                          child: new Row(
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              new Flexible(
                                child: new TextField(
                                  decoration: const InputDecoration(
                                      hintText: "Key Collection Instructions"),
// enabled: !_status,
                                ),
                              ),
                            ],
                          )),
                      Padding(
                          padding: EdgeInsets.only(
                              left: 25.0, right: 25.0, top: 0.0),
                          child: new Row(
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              new Flexible(
                                child: new TextField(
                                  decoration: const InputDecoration(
                                      hintText: "Gate codes Instructions"),
// enabled: !_status,
                                ),
                              ),
                            ],
                          )),
                      Padding(
                          padding: EdgeInsets.only(
                              left: 25.0, right: 25.0, top: 15.0),
                          child: new Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              new Column(

                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[

                                  new Text(

                                    'Save As',
                                    style: TextStyle(
                                        color:Colors.deepPurpleAccent,
                                        fontSize: 15.0,

                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                              new Column(

                              )
                            ],
                          )),
                      new Container(
                        padding: EdgeInsets.all(3.0),
                        child: Row(


                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(left:20.0),
                              child:
                              Container(
                                alignment: Alignment.center,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Container(


                                        child: Container(
                                          color:Colors.deepPurpleAccent,

                                          child: Column(

                                            children: <Widget>[

                                              Container(

                                                padding: EdgeInsets.all(5.0),
                                                child: Text(
                                                  'HOME',style: TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.white,
                                                ),
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                                width: 70.0,
                                height: 30.0,
                                decoration: new BoxDecoration(
                                  shape: BoxShape.rectangle,

                                ),
                              ),),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Container(
                                alignment: Alignment.center,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      flex: 1,
                                      child: Container(
                                        decoration: new BoxDecoration(
                                            borderRadius: BorderRadius.circular(10.0),
                                            color: Colors.white
                                        ),
                                        child: Container(
                                          child: Column(
                                            children: <Widget>[
                                              Container(
                                                padding: EdgeInsets.all(5.0),
                                                child: Text(
                                                  'OFFICE',style: TextStyle(
                                                  fontSize: 15,
                                                  color:Colors.deepPurpleAccent,
                                                ),
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                                width: 70.0,
                                height: 30.0,
                                decoration: new BoxDecoration(
                                  shape: BoxShape.rectangle,
                                  border: Border.all(color: Colors.deepPurpleAccent),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),),
                            Container(
                              alignment: Alignment.center,
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    flex: 1,
                                    child: Container(
                                      decoration: new BoxDecoration(
                                          borderRadius: BorderRadius.circular(25.0),
                                          color: Colors.white
                                      ),
                                      child: Container(
                                        child: Column(
                                          children: <Widget>[
                                            Container(
                                              padding: EdgeInsets.all(5.0),
                                              child: Text(
                                                'OTHER',style: TextStyle(
                                                fontSize: 15,
                                                color: Colors.deepPurpleAccent,
                                              ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              width: 70.0,
                              height: 30.0,
                              decoration: new BoxDecoration(
                                shape: BoxShape.rectangle,
                                border: Border.all(color: Colors.deepPurpleAccent),
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ],
                        ),
                      )

// !status ? getActionButtons() : new Container(),
                    ],
                  ),
                ),
              ),



            ],),



        ],

      ),),
      bottomNavigationBar: new Container(

        color: Color.fromRGBO(125, 121, 204, 1),
        height: 52,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[


                Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: FlatButton(
                    child:Align(
                      alignment: FractionalOffset.center,
                    ),
                  ),),



                Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: FlatButton(
                    child:Align(
                      alignment: FractionalOffset.center,
                      child: Text(
                        "Save Address",style: TextStyle(color: Colors.white,fontSize: 18),textAlign: TextAlign.center,

                      ),),onPressed: (){
                    _navigateToNextScreen(context);
                  },
                  )
                  ,),
                Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: FlatButton(
                    child:Align(
                      alignment: FractionalOffset.center,
                    ),
                  ),),
              ],),
          ),



    );
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Payment()),
    );
  }

}