import 'package:flutter/material.dart';

class ProviderBookingHistoryTabBar extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(

        appBar: AppBar(
          title: new Center(child: new Text("Ongoing Leads", textAlign: TextAlign.center)),
          backgroundColor: Color.fromRGBO(241, 123, 72, 1),
          bottom: TabBar(
            tabs: [
              Tab( text: "Ongoing Leads",),
              Tab( text: "Past Leads"),
            ],
          ),

        ),
        body: TabBarView(
          children: [
            Center( child: Text("No data found")),
            Center( child: Text("No data found")),
          ],
        ),
      ),
    );
  }
}