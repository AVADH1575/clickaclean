import 'dart:io';
import 'package:click_a_clean/ProviderEnd/AccountSetup/BankDetails/BankDetailsSecond.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/PersonalInformation/personal_information_third.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/Profile/provider_edit_profile_screen.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/ProviderHelp/ProviderHelp.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/ProviderHistory/Provider_booking_history.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/TermsAndConditions.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/VerifyAccount/IdentityVerificationSubmitVideo.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/VerifyAccount/TermsProfileProvider.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/VerifyAccount/verify_identity_second.dart';
import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:click_a_clean/UserEnd/login/login_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';

import 'EditIdentity.dart';



class ProvideProfileScreen extends StatefulWidget {

  ProvideProfileScreen({Key key}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return _ProvideProfileScreen();
  }
}

class _ProvideProfileScreen extends State<ProvideProfileScreen> {
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  File _image;
  void showInSnackBar(String value) {
    scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(value)));}

  @override
  void initState() {
    super.initState();
  }
  void open_camera(BuildContext context)
  async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    setState(() {
      _image = image ;
    });
    Navigator.of(context).pop();

  }
  void open_gallery(BuildContext context)
  async {
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      _image = image ;
    });
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: scaffoldKey,
       // appBar: AppBar(title: Text("Identity Verification"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),),

        body: SingleChildScrollView(

            child:
            Container(
                color: Color.fromRGBO(248, 248, 248, 1),
                child:Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[
                   Column(
                children: <Widget>[
                    Container(
                      color: Color.fromRGBO(248, 248, 248, 1),
                      child:
                      Padding(
                        padding: EdgeInsets.fromLTRB(5, 25, 5, 0),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[

                            IconButton(icon: Icon(Icons.arrow_back_ios,color: Color.fromRGBO(112, 112, 112, 1),),),
                            Text("Profile",style: TextStyle(color: Color.fromRGBO(112, 112, 112, 1), fontSize: 20),),
                            IconButton(icon: Icon(Icons.notifications_none,color: Color.fromRGBO(240, 122, 71, 1),),),

                          ],
                        ),),

                    ),
                      Container(
                        color: Color.fromRGBO(248, 248, 248, 1),
                      child:Row(
                       // mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Column(
                            // mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[


                         FlatButton(
                         child:new Stack(fit: StackFit.loose,
                             children: <Widget>[
                               new Row(
                                //mainAxisAlignment: MainAxisAlignment.center,
                                 children: <Widget>[
                                   new Container(
                                       width: 90.0,
                                       height: 90.0,

                           child: _image == null ? Image.asset('assets/images/logo_img.png') : Image.file(_image),),

                                 ],
                               ),
                               Padding(
                                   padding: EdgeInsets.only(top: 60.0, left: 65.0,bottom: 15),
                                   child: new Row(

                                     mainAxisAlignment: MainAxisAlignment.center,
                                     children: <Widget>[

                                       Container(
                                         height:28,
                                       width:28,
                                           decoration:BoxDecoration(borderRadius: BorderRadius.circular(14.0),color: Color.fromRGBO(39, 180, 221, 1),),

                                         child:
                                         new Icon(
                                           Icons.edit,
                                           color: Colors.white,
                                         ),

                                       )
                                     ],
                                   )),
                             ]),onPressed: (){
                           _showChoiceDailog(context);
                         },
                       ),
                            ],),
                          Align(
                            alignment: FractionalOffset.topLeft,
                          child:Padding(
                            padding: EdgeInsets.fromLTRB(11, 17, 0, 0),

                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[

                            Align(
                            alignment: Alignment.topLeft,

                                child:Text("Thompson S.",style: TextStyle(color: Color.fromRGBO(112, 112, 112, 1), fontSize: 18),textAlign: TextAlign.start,),),
                                Text("Park Avenue Street20 , Paris , France",style: TextStyle(color: Color.fromRGBO(112, 112, 112, 1), fontSize: 13),),
                                 Icon(Icons.star,color: Color.fromRGBO(254, 222, 15, 1),)

                              ],
                            ),),

                          ),



                        ],),),
                     Container(

                       decoration: new BoxDecoration(
                           borderRadius: BorderRadius.circular(10.0),
                           color: Colors.white
                       ),
                       margin: EdgeInsets.fromLTRB(4, 0, 4, 0),
                       child:Column(
                           mainAxisAlignment: MainAxisAlignment.start,
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children: <Widget>[

                  Container(
                    //padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                    child:
                    FlatButton(

                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                              'Account Settings',
                              style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                              textAlign: TextAlign.start
                          ),

                          Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                        ],
                      ),
                    onPressed: (){
                        _navigateToAccountSettingScreen(context);
                    },),
                  ),
                       Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),


                             Container(
                               padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                               child:
                               FlatButton(

                                 child: Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                     Row(
                                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                       children: [
                                         // SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                         Padding(
                                             padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                                             child: Text(
                                                 'Identity',
                                                 style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                 textAlign: TextAlign.start
                                             ))
                                         ,],),
                                     new Container(
                                     ),
                                     Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                   ],
                                 ),
                               onPressed: (){
//                                 Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
//                                     builder: (context) => EditIdentityScreen(), maintainState: false));

                                   scaffoldKey.currentState
                                       .showSnackBar(new SnackBar(content: new Text("Pending")));

                               },
                               ),
                             ),

                             Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                             Container(
                               padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                               child:
                               FlatButton(

                                 child: Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                     Row(
                                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                       children: [
                                         // SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                         Padding(
                                             padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                                             child: Text(
                                                 'Bank Details',
                                                 style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                 textAlign: TextAlign.start
                                             )),],),
                                     new Container(
                                     ),
                                     Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                   ],
                                 ),onPressed: (){
                                 Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
                                     builder: (context) => BankDetailsSecond(), maintainState: false));
                               },),
                             ),

                             Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                             Container(
                               padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                               child:
                               FlatButton(

                                 child: Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                     Row(
                                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                       children: [
                                         // SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                         Padding(
                                             padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                                             child: Text(
                                                 'Add Photos',
                                                 style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                 textAlign: TextAlign.start
                                             )),],),
                                     new Container(
                                     ),
                                     Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                   ],
                                 ),onPressed: (){
                                 scaffoldKey.currentState
                                     .showSnackBar(new SnackBar(content: new Text("Pending")));
                               },),
                             ),

                             Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                             Container(
                               padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                               child:
                               FlatButton(

                                 child: Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                     Row(
                                      // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                       children: [
                                         // SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                         Padding(
                                             padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                                             child: Text(
                                                 'History',
                                                 style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                                 textAlign: TextAlign.start
                                             )),],),
                                     new Container(
                                     ),
                                     Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                                   ],
                                 ),onPressed: (){
                                 _navigateToBookingHistory(context);
                               },),
                             ),
                            // Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),


                           ],),),
                  Column(


                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[

                      Container(
                        //padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child:
                        FlatButton(

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                  'Terms of Use',
                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                  textAlign: TextAlign.start
                              ),

                              Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                            ],
                          ),onPressed: (){
                          Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
                              builder: (context) => TermsAndConditionsProfile(), maintainState: false));
                        },),
                      ),
                      Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),


                      Container(
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child:
                        FlatButton(

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  // SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                  Padding(
                                      padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                                      child: Text(
                                          'Privacy Policy',
                                          style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                          textAlign: TextAlign.start
                                      )),],),
                              new Container(
                              ),
                              Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                            ],
                          ),onPressed: (){
                          scaffoldKey.currentState
                              .showSnackBar(new SnackBar(content: new Text("Pending")));
                        },),
                      ),

                      Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child:
                        FlatButton(

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  // SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                  Padding(
                                      padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                                      child: Text(
                                          'Help',
                                          style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                          textAlign: TextAlign.start
                                      )),],),
                              new Container(
                              ),
                              Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                            ],
                          ),
                        onPressed: (){
                          Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
                              builder: (context) => ProviderHelpScreen(), maintainState: true));
                        },),
                      ),

                      Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child:
                        FlatButton(

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  // SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                  Padding(
                                      padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                                      child: Text(
                                          'Contact Us',
                                          style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                          textAlign: TextAlign.start
                                      )),],),
                              new Container(
                              ),
                              Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                            ],
                          ),onPressed: (){
                          scaffoldKey.currentState
                              .showSnackBar(new SnackBar(content: new Text("Pending")));
                        },),
                      ),

                      Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child:
                        FlatButton(

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                // mainAxisAlignment: MainAxisAlignment.spaceEvenly,

                                children: [
                                  // SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                  Padding(
                                      padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                                      child: Text(
                                          'Rate App on Playstore',
                                          style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 15),
                                          textAlign: TextAlign.start
                                      )),],),
                              new Container(
                              ),
                              Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(129, 130, 130, 1))
                            ],
                          ),onPressed: (){
                          scaffoldKey.currentState
                              .showSnackBar(new SnackBar(content: new Text("Pending")));
                        },),
                      ),
                      Container(height: 0.5,color: Color.fromRGBO(0, 0, 0, 0.16)),

                    ],)

                       ],),

                    FlatButton(

                      child: Container(
                        child:

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text('Logout',style: TextStyle(
                                fontSize: 16,fontWeight: FontWeight.bold,
                                color:Color.fromRGBO(255, 0, 0, 1))),
                            //Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),

//                           Column(
//                               children: <Widget>[
//                            FlatButton(
//                              onPressed: () {},
//                              child:Icon(Icons.play_circle_filled,color: Color.fromRGBO(241, 123, 72, 1),)
//                            )],)
                          ],
                        ),

                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      textColor: Color.fromRGBO(255, 0, 0, 1),

                      //splashColor: Color.fromRGBO(0, 0, 0, 0.16),

                      onPressed: () {
                        //_navigateToNextScreen(context);
                      },
                    )


                  ],))));
  }
  void _navigateToHelpScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ProviderHelpScreen()),
    );
  }
  void _navigateToAccountSettingScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ProviderEditProfilePage()),
    );
  }
  void _navigateToEditIdentityScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => EditIdentityScreen()),
    );
  }
  void _navigateToEditBankDetail(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BankDetailsSecond()),
    );
  }
  void _navigateToBookingHistory(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ProviderBookingHistoryTabBar()),
    );
  }
  Future<void> _showChoiceDailog(BuildContext context){
    return showDialog(context: context, builder : (BuildContext context){
      return AlertDialog(
        title: Text("Make a Choice!",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w300),textAlign: TextAlign.center,),
        content: SingleChildScrollView(
          child: ListBody(

            children: <Widget>[
          Align(
          alignment: Alignment.center,
              child:GestureDetector(

                child: Row(

                  //mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[

                    Icon(Icons.photo_library),
                    Padding(
                        padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
                        child:Text("Gallery",style: TextStyle(fontSize: 14),)
                    ),
                  ],),

                onTap: (){
                  open_gallery(context);
                },
              ),),
              Align(
                alignment: Alignment.center,
              child:Padding(
                  padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
              child:GestureDetector(
                child:Row(
                //  mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[

                  Icon(Icons.camera),
                  Padding(
                      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
                      child:Text("Camera",style: TextStyle(fontSize: 14),)
                  ),
                ],),
                onTap: (){
                  open_camera(context);
                },
              )
      ),),

            ],
          ),
        ),
      );
    });
  }
}