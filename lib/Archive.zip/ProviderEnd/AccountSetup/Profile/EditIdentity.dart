import 'package:click_a_clean/ProviderEnd/AccountSetup/PersonalInformation/personal_information_second.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/Profile/provider_profile_screen.dart';
import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:click_a_clean/UserEnd/login/login_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';



class EditIdentityScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _EditIdentityScreen();
  }
}
class _EditIdentityScreen extends State<EditIdentityScreen> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("Identity"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),),

        body: SafeArea(

            child:
            Align(

                child:Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[

                    Column(
                        children: <Widget>[
                          Container(
                            margin:  EdgeInsets.fromLTRB(33, 29, 33, 0),
                            height: 40,
                            decoration: new BoxDecoration(
                                borderRadius: BorderRadius.circular(10.0),
                                border: Border.all(color: Color.fromRGBO(218, 218, 218, 1)),
                                color: Colors.white
                            ),
                            child: FlatButton(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                                children: <Widget>[
                                  Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,

                                children: <Widget>[
                                  Text("Type of ID",style: TextStyle(color: Color.fromRGBO(197, 197, 197, 1),fontSize: 12)),
                                  Text("National ID",style: TextStyle(color: Color.fromRGBO(174, 175, 175, 1),fontSize: 14)),
                                ],),
                                  Icon(Icons.keyboard_arrow_down,color: Color.fromRGBO(174, 175, 175, 1))


                                ],
                              ),
                            ),

                          ),

                        ]),



                    Align(
                      alignment: Alignment.center,

                      child:Container(

                        color: Color.fromRGBO(241, 123, 72, 1),
                        height: 49,

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Align(
                              alignment: FractionalOffset.bottomRight,
                              child: FlatButton(
                                onPressed: (){
                                  //_navigateToNextScreen(context);
                                },
                                child: Row(

                                  children: <Widget>[
                                    Row(

                                      children: <Widget>[
                                        FlatButton(
                                            onPressed: () {},
                                            child: Column(
                                              children: <Widget>[


                                              ],)
                                        ),
                                      ],),


//Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),


                                  ],
                                ),
                              ),),
                            Align(
                              alignment: FractionalOffset.bottomRight,
                              child: FlatButton(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Align(
                                          alignment: FractionalOffset.center,
                                          child:FlatButton(
                                              onPressed: () {
                                               // _navigateToNextScreen(context);
                                              },
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: <Widget>[
                                                  Text("SAVE",style: TextStyle(color: Colors.white,fontSize: 16)),
                                                  Icon(Icons.arrow_forward_ios,color: Colors.white,)
                                                ],)
                                          ),),
                                      ],),


                                  ],
                                ),
                              ),),

                          ],),
                      ),)


                  ],))));
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ProvideProfileScreen()),
    );
  }

}