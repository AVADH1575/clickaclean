import 'package:click_a_clean/ProviderEnd/AccountSetup/Home/ChooseProfessionProvider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http;
import 'ProviderOtpscreen.dart';
import 'dart:convert';


class ProviderLoginScreen extends StatefulWidget {
  @override

  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ProviderLoginScreen();
  }
}

class _ProviderLoginScreen extends State<ProviderLoginScreen> {

  TextEditingController EmailControler = new TextEditingController();

  bool _isVisible = true;


  void showToast() {
    setState(() {
      _isVisible = !_isVisible;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body: Padding(
            padding: EdgeInsets.all(0),
            child: ListView(
              children: <Widget>[
                Container(
                  color: Color.fromRGBO(241, 123, 72, 1),
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(10),

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0, 3, 0, 0),
                        child: Align(
                          alignment: Alignment.center,
                          child: SvgPicture.asset(
                            'assets/images/white-logo.svg',

                            // fit: BoxFit.contain,
                            height: 50,


                          ),
                        ),
                      ),
                      Container(
                          padding: EdgeInsets.fromLTRB(20, 5, 0, 0),
                          child: Align(
                            alignment: Alignment.topLeft,

                            child: RichText(
                              textAlign: TextAlign.left,
                              text: TextSpan(
                                text: 'Login/Create Account \n',
                                style: TextStyle(color: Colors.white,fontSize: 20.0 ), /*defining default style is optional */
                                children: <TextSpan>[
                                  TextSpan(
                                      text: 'To get personalised experience', style: TextStyle(color: Colors.white,fontSize: 18.0)),

                                ],
                              ),
                            ),

                          )),
                    ],

                  ),
                ),


                Container(
                  padding: EdgeInsets.fromLTRB(20,30,20,0),
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(0,0,0,5),
                    child:
//                  TextField(
//
//                decoration: const InputDecoration(
//                    hintText: "Enter Mobile Number/Email ID",
//                    contentPadding: const EdgeInsets.fromLTRB(0,20,20,20),
//                suffixIcon:
//                IconButton(
//                  icon: Image(image: AssetImage("assets/images/next_icon.png"),height: 40,width: 40),
//
//                  //onPressed: ,
//                )
//
//               // Image(image: AssetImage("assets/images/next_icon.png"),height: 0,width: 0)
//                ),
//
//
//                ),
                     TextFormField(
                      controller: EmailControler,
                      decoration: InputDecoration(
                        hintText: 'Enter Mobile Number/Email ID',

                        suffixIcon: IconButton(
                            icon: Image(image: AssetImage("assets/images/next_icon.png"),height: 40,width: 40),

                          onPressed: () async {
                              _navigateToChooseProfessionScreen(context);

//Post newPost = new Post(
//userId: "123", id: 0, title: titleControler.text, body: bodyControler.text);
//Post p = await createPost(CREATE_POST_URL,
//body: newPost.toMap());
//print(p.title);

                          //==================== working api ====================

//                            var client = new http.Client();
//                            try{
//                              var response = await client.post(
//                                  "https://sharpwebstudio.us/clickaclean/api/user/UserSignup",
//                                  headers: {"x-api-key" : "boguskey"/*, ...etc*/},
//                                  body : {
//                                    'email': EmailControler.text,
//                                  }
//
//                              );
//
//
//
//                              if(response.statusCode == 200 || response.statusCode == 201){
//                                //enter your code
//
//                                print("Response status: ${response.statusCode}");
//                                print("Response body: ${response.body}");
//
//
//                                final jsonData = json.decode(response.body);
//                                if(jsonData["status"] == "true"){
//                                  print("JSONResponse : ${jsonData["data"][0]["email"]}");
//                                  _navigateToChooseProfessionScreen(context);
//                                }
//
//                              else{
//
//                            var client = new http.Client();
//                              try {
//                            var response = await client.post(
//                           "http://sharpwebstudio.us/clickaclean/api/user/login",
//                             headers: {"x-api-key": "boguskey" /*, ...etc*/
//                           },
//                           body: {
//                             'email': EmailControler.text,
//                               }
//
//                           );
//
//
//                             if (response.statusCode == 200 || response.statusCode == 201) {
//                             //enter your code
//
//                            print("Response status: ${response.statusCode}");
//                             print("Response body: ${response.body}");
//
//
//                            final jsonData = json.decode(response.body);
//                            if (jsonData["status"] == true) {
//                           print("JSONResponse : ${jsonData["data"][0]["email"]}");
//                           _navigateToChooseProfessionScreen(context);
//                            }
//
//                              else {
//
//                            }
//                            }
//                           } on Exception catch (err) {
//                           print("Error : $err");
//                             }
//
//
//                                }
//
//
//                              }
//                            } on Exception catch (err){
//                              print("Error : $err");
//                            }
//
                          },
                            ),),),),),


                SizedBox(height: 10),
                Container(
                    padding:EdgeInsets.fromLTRB(10, 15, 10, 0) ,
                    child: Column(
                      children: <Widget>[
                        Center(

                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text: 'Your personal details are secure with us.Read our',
                              style: TextStyle(color: Color.fromRGBO(169, 189, 212, 1),fontSize: 12.5 ), /*defining default style is optional */
                              children: <TextSpan>[
                                TextSpan(
                                    text: ' Privacy', style: TextStyle(fontWeight: FontWeight.bold,color: Color.fromRGBO(241, 123, 72 ,1),fontSize: 12.5)),
                                TextSpan(
                                    text: ' Policy',
                                    style: TextStyle(color: Color.fromRGBO(241, 123, 72 ,1),fontSize: 12.5,fontWeight: FontWeight.bold)),
                                TextSpan(
                                    text: ' to know more.By Proceeding further you agree to our\n',
                                    style: TextStyle(color: Color.fromRGBO(169, 189, 212, 1), fontSize: 12.5)),
                                TextSpan(
                                    text: 'Terms and Conditions ',
                                    style: TextStyle(color: Color.fromRGBO(241, 123, 72 ,1), fontSize: 12.5,fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),),

                        FlatButton(
                          textColor: Colors.grey,
                          onPressed: () {
                            //signup screen
                          },
                        )
                      ],
                      mainAxisAlignment: MainAxisAlignment.center,
                    ))
              ],
            )));
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ProviderOTPScreen()),
    );
  }
  void _navigateToChooseProfessionScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ChooseProfessionProvider()),
    );
  }

}
