
import 'package:click_a_clean/UserEnd/menu_fragment/booking_history/booking_time.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';


class ProviderHomeMenu extends StatefulWidget {

  @override
  State<StatefulWidget> createState() {
  return _ProviderHomeMenu();
  }
  }
  class _ProviderHomeMenu extends State<ProviderHomeMenu> {

    @override
  void initState() {
    // TODO: implement initState
     // _child = RippleIndicator("Geting Location");
    super.initState();
  }



  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            child: Container(
              color: Color.fromRGBO(241, 123, 72, 1),
              child: Column(


               children: <Widget>[

                  Container(
                    height: 72,
                    color: Color.fromRGBO(241, 123, 72, 1),
                    child:
                    Row(

                      children: [


                    Column(

                      children: [
                        SizedBox(height: 20.0,),
                        Padding(
                          padding: EdgeInsets.only(left: 20,right: 0),
                        child:Text('Car Clean',
                          style: TextStyle(
                              decoration: TextDecoration.none,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                              fontSize: 16),
                        ),),
                        SizedBox(height: 5.0,),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Padding(
                              padding: EdgeInsets.only(left: 20.0, right: 10.0),
                              child: Container(
                                  height: 20,
                                  width: 20,

                                  alignment: Alignment.topLeft,
                                  decoration: new BoxDecoration(
                                      image: new DecorationImage(
                                        image: new AssetImage('assets/images/location_icon_white.png'),
                                        fit: BoxFit.cover,
                                      )
                                  )

                              ),),

                            Text(
                              'Park Avenue Street17 , Paris , France',
                              style: TextStyle(
                                  decoration: TextDecoration.none,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16),
                            )

                          ],),


                      ],),
                        Column(
                           mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              color: Color.fromRGBO(241, 123, 72, 1),
                              height: 20,
                            width: 20,
                            child:FlatButton(

                              child: Icon(Icons.notifications),
                              textColor: Colors.white,
                              onPressed: () {
                                //signup screen
                              },
                            ),)
                          ],),
            ])),

                  //SizedBox(height: 20.0,),
                 Container(
                     decoration: BoxDecoration(
                   color: Colors.white,
                   image: DecorationImage(
                       image: AssetImage('assets/images/map.jpg'),
                       fit: BoxFit.cover
                   ),),
                     height: 600,
                     alignment: Alignment.topLeft,

                 )

                ],



              ),
            ),

          ),
        ),
      ),
    );

  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BookingTime()),
    );
  }
}