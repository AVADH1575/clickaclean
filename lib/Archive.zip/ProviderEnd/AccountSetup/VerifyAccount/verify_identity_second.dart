import 'package:click_a_clean/ProviderEnd/AccountSetup/PersonalInformation/personal_information_third.dart';
import 'package:click_a_clean/ProviderEnd/AccountSetup/VerifyAccount/verifyCountry_choose.dart';
import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:click_a_clean/UserEnd/login/login_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class VerifyIdentySecond extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _VerifyIdentySecond();
  }
}
class _VerifyIdentySecond extends State<VerifyIdentySecond> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("Identity Verification"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),),

        body: SafeArea(

            child:
            Align(

                child:Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[

                    Column(
                        children: <Widget>[



                          Align(
                            alignment: Alignment.center,
                            child: Padding(
                                padding:  EdgeInsets.fromLTRB(23, 30, 23, 0),
                                child:
                                Text("Select a document",
                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1) ,fontSize: 21),textAlign: TextAlign.center,)
                            ),
                          ),

                          Align(
                            alignment: Alignment.center,
                            child: Padding(
                                padding:  EdgeInsets.fromLTRB(23, 9, 23, 0),
                                child:
                                Text("You will take picture of it in next step",
                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1) ,fontSize: 16),textAlign: TextAlign.center,)
                            ),
                          ),
                      Padding(
                         padding:  EdgeInsets.fromLTRB(0, 38, 0, 0),
                          child:Divider(
                              color: Color.fromRGBO(0, 0, 0, 0.16)
                          ),),
                          Container(
                            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                            child:
                            FlatButton(

                           child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                              Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                SvgPicture.asset('assets/images/passport.svg',height: 18,width: 18,),
                                Padding(
                                  padding:  EdgeInsets.fromLTRB(10, 0, 0, 0),
                               child: Text(
                                    'Passport',
                                    style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 13),
                                    textAlign: TextAlign.start
                                )),],),
                                new Container(
                                ),
                                Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(241, 123, 72, 1))
                              ],
                            ),onPressed: (){
                              _navigateToNextScreen(context);
                            },),
                          ),

                          Padding(
                            padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                            child:Divider(
                                color: Color.fromRGBO(0, 0, 0, 0.16)
                            ),),
                          Container(
                            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                            child:
                            FlatButton(

                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      SvgPicture.asset('assets/images/driving.svg',height: 16,width: 16,),
                                      Padding(
                                          padding:  EdgeInsets.fromLTRB(10, 0, 0, 0),
                                          child: Text(
                                              'Driving License',
                                              style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 13),
                                              textAlign: TextAlign.start
                                          )),],),
                                  new Container(
                                  ),
                                  Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(241, 123, 72, 1))
                                ],
                              ),
                            onPressed: (){
                                _navigateToNextScreen(context);
                            },),
                          ),
                          Padding(
                            padding:  EdgeInsets.fromLTRB(0, 0, 0, 0),
                            child:Divider(
                                color: Color.fromRGBO(0, 0, 0, 0.16)
                            ),),
                          Container(
                            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                            child:
                            FlatButton(

                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [

                                      SvgPicture.asset('assets/images/national-id.svg',height: 16,width: 16,),
                                      Padding(
                                          padding:  EdgeInsets.fromLTRB(10, 0, 0, 0),
                                          child: Text(
                                              'National ID',
                                              style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 13),
                                              textAlign: TextAlign.start
                                          )),],),
                                  new Container(
                                  ),
                                  Icon(Icons.arrow_forward_ios,color: Color.fromRGBO(241, 123, 72, 1))
                                ],
                              ),onPressed: (){
                              _navigateToNextScreen(context);
                            },),
                          ),

                          Padding(
                            padding:  EdgeInsets.fromLTRB(0, 5, 0, 0),
                            child:Divider(
                                color: Color.fromRGBO(0, 0, 0, 0.16)
                            ),),
                        ]),




                  ],))));
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => VerifyCountryChoose()),
    );
  }

}