import 'dart:io';

import 'package:click_a_clean/ProviderEnd/AccountSetup/AccountSetupMain.dart';

import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:click_a_clean/UserEnd/login/login_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'IdentintyVerificationRecordSelfieVideo.dart';

class IdentitySelfieConfirmation extends StatefulWidget {

  final String imagePath;
  var check_front;
  var check_back;


  IdentitySelfieConfirmation({this.imagePath,this.check_front,this.check_back});
  @override
  State<StatefulWidget> createState() {
    return _IdentitySelfieConfirmation();
  }

}
class _IdentitySelfieConfirmation extends State<IdentitySelfieConfirmation> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("Take a selfie"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),),

        body: SafeArea(

            child:
            Align(
                alignment: Alignment.center,
                child:Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[
                    Align(
                      alignment: FractionalOffset.center,
                      child:Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[

                            Padding(
                              padding:  EdgeInsets.fromLTRB(17, 89, 17, 0),
                              child:Container(
                                height: 226,
                                width: 226,
                                  child: Image.file(File(widget.imagePath), fit: BoxFit.cover)

                                //decoration: new BoxDecoration( borderRadius: BorderRadius.circular(113),color: Color.fromRGBO(218, 218, 218, 1))
                              ),
                            ),

                            Padding(
                                padding:  EdgeInsets.fromLTRB(29, 54, 29, 0),
                                child:
                                Text("Make sure your selfie clearly shows your face",
                                  style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 16),textAlign: TextAlign.center,)
                            ),
                          ]),),

                    Column(
                      children: <Widget>[

                        Container(
                            height: 60,
                            padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            margin:  EdgeInsets.fromLTRB(34, 0, 34, 5),

                            child: RaisedButton(

                              child: Container(
                                child:

                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text('CONFIRM MY SELFIE',style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.white,)),
                                    //Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),

//                           Column(
//                               children: <Widget>[
//                            FlatButton(
//                              onPressed: () {},
//                              child:Icon(Icons.play_circle_filled,color: Color.fromRGBO(241, 123, 72, 1),)
//                            )],)
                                  ],
                                ),

                              ),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              textColor: Colors.white,
                              color: Color.fromRGBO(241, 123, 72, 1),
                              splashColor: Color.fromRGBO(0, 0, 0, 0.16),

                              onPressed: () {
                                _navigateToNextScreen(context);
                              },
                            )),

                        Container(
                            height: 60,
                            padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            margin:  EdgeInsets.fromLTRB(34, 0, 34, 20),

                            child: RaisedButton(

                              child: Container(
                                child:

                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text('TAKE A NEW SELFIE',style: TextStyle(
                                        fontSize: 16,
                                        color: Color.fromRGBO(241, 123, 72, 1))),
                                    //Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),

//                           Column(
//                               children: <Widget>[
//                            FlatButton(
//                              onPressed: () {},
//                              child:Icon(Icons.play_circle_filled,color: Color.fromRGBO(241, 123, 72, 1),)
//                            )],)
                                  ],
                                ),

                              ),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  side: BorderSide(color: Color.fromRGBO(241, 123, 72, 1))
                              ),
                              textColor: Color.fromRGBO(241, 123, 72, 1),
                              color: Colors.white,


                              onPressed: () {
                                _navigateToNextScreen(context);
                              },
                            ))

                      ],),



                  ],))));
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AccountSetupMAIN()),
    );
  }

}