import 'dart:io';


import 'package:click_a_clean/UserEnd/camera_screen.dart';
import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:click_a_clean/UserEnd/login/login_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'CameraBackClick.dart';
import 'IdentintyVerificationRecordSelfieVideo.dart';

class IdentityAllowCameraAccessSecond extends StatefulWidget {
  final String imagePath;
  var check_front;
  var check_back;


  IdentityAllowCameraAccessSecond({this.imagePath,this.check_front,this.check_back});
  @override
  State<StatefulWidget> createState() {
    return _IdentityAllowCameraAccessSecond();
  }
}
class _IdentityAllowCameraAccessSecond extends State<IdentityAllowCameraAccessSecond> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  var _firstPress = true ;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("National ID"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),),

        body: SafeArea(

            child:
            Align(
alignment: Alignment.center,
                child:Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[
                    Align(
                      alignment: FractionalOffset.center,
                    child:Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[

                          Padding(
                            padding:  EdgeInsets.fromLTRB(17, 117, 17, 0),
                            child:Container(
                              height: 189,
                              width: 220,
                              color: Color.fromRGBO(218, 218, 218, 1),
                                child: Image.file(File(widget.imagePath), fit: BoxFit.cover)
                            ),
                          ),

                          Padding(
                              padding:  EdgeInsets.fromLTRB(29, 51, 29, 0),
                              child:
                              Text("Make sure your card details are clear to read, with no blur or glare",
                                style: TextStyle(color: Color.fromRGBO(81, 92, 111, 1),fontSize: 14),textAlign: TextAlign.center,)
                          ),
                        ]),),

                    Column(
                      children: <Widget>[

                        Container(
                            height: 60,
                            padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            margin:  EdgeInsets.fromLTRB(34, 0, 34, 5),

                            child: RaisedButton(



                    child: Container(
                    child:

                    Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[


                    Text('MY CARD IS READABLE',style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,)),
                    //Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),

//                           Column(
//                               children: <Widget>[
//                            FlatButton(
//                              onPressed: () {},
//                              child:Icon(Icons.play_circle_filled,color: Color.fromRGBO(241, 123, 72, 1),)
//                            )],)
                    ],
                    ),

                    ),
                    shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                    textColor: Colors.white,
                    color: Color.fromRGBO(241, 123, 72, 1),
                    splashColor: Color.fromRGBO(0, 0, 0, 0.16),

                    onPressed: ()  async{
                      if(widget.check_front = true){

                        _navigateToNextScreenCamera(context);


                    //_navigateToNextScreen(context);
                    }
                    if(widget.check_back = true){


                        _navigateToNextScreen(context);
                      }
                    } )),

                        Container(
                            height: 60,
                            padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            margin:  EdgeInsets.fromLTRB(34, 0, 34, 20),

                            child: RaisedButton(

                              child: Container(
                                child:

                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text('TAKE A NEW PICTURE',style: TextStyle(
                                      fontSize: 16,
                                      color: Color.fromRGBO(241, 123, 72, 1))),
                                    //Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),

//                           Column(
//                               children: <Widget>[
//                            FlatButton(
//                              onPressed: () {},
//                              child:Icon(Icons.play_circle_filled,color: Color.fromRGBO(241, 123, 72, 1),)
//                            )],)
                                  ],
                                ),

                              ),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  side: BorderSide(color: Color.fromRGBO(241, 123, 72, 1))
                              ),
                              textColor: Color.fromRGBO(241, 123, 72, 1),
                              color: Colors.white,


                              onPressed: () {
                                _navigateToNextScreenCamera(context);
                              },
                            ))

                      ],),



                  ],))));
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => IdentityRecordSelfieVideo()),
    );
  }
  void _navigateToNextScreenCamera(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CameraBackScreenClick()),
    );
  }

}