import 'package:flutter/material.dart';

class NewLeadScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _NewLeadScreen();
  }
}
class _NewLeadScreen extends State<NewLeadScreen> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(title: Text("New Leads"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),centerTitle: true,),

      body: Container(
        child:
        Align(
          alignment: FractionalOffset.center,
        child:Center(child: Text("No data found"),),),

      ),
    );
  }
}