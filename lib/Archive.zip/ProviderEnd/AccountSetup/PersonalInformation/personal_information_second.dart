import 'package:click_a_clean/ProviderEnd/AccountSetup/PersonalInformation/personal_information_third.dart';
import 'package:click_a_clean/UserEnd/home_widget.dart';
import 'package:click_a_clean/UserEnd/login/login_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:percent_indicator/percent_indicator.dart';

class PersonalInformationSecond extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _PersonalInformationSecond();
  }
}
class _PersonalInformationSecond extends State<PersonalInformationSecond> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String value = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //appBar: AppBar(title: Text("Account Setup"), backgroundColor: Color.fromRGBO(241, 123, 72, 1),),

        body: SafeArea(

            child:
            SingleChildScrollView(

                child:Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[

                    Column(
                        children: <Widget>[
                          Container(
                              alignment: Alignment.center,
                              padding:  EdgeInsets.fromLTRB(10, 0, 15, 0),
                              color: Color.fromRGBO(241, 123, 72, 1),
                              height: 73,
                              child:Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                                  children: <Widget>[

                                    IconButton(
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                        icon: Icon(Icons.arrow_back_ios,color: Colors.white)
                                    ),

                                    Padding(
                                      padding: EdgeInsets.all(0.0),
                                      child:  LinearPercentIndicator(
                                        width: 210,
                                        animation: true,
                                        lineHeight: 20.0,
                                        animationDuration: 2000,
                                        percent: 0.4,

                                        linearStrokeCap: LinearStrokeCap.roundAll,
                                        progressColor: Colors.white,
                                      ),
                                    ),
                                    Icon(Icons.help,color: Colors.white,)
                                    //Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),

//                           Column(
//                               children: <Widget>[
//                            FlatButton(
//                              onPressed: () {},
//                              child:Icon(Icons.play_circle_filled,color: Color.fromRGBO(241, 123, 72, 1),)
//                            )],)
                                  ],
                                ),

                              )),


                          Align(
                            alignment: Alignment.topLeft,
                            child: Padding(
                                padding:  EdgeInsets.fromLTRB(23, 28, 23, 0),
                                child:
                                Text("Email*",
                                  style: TextStyle(color:Color.fromRGBO(241, 123, 72, 1) ,fontSize: 14),)
                            ),
                          ),
                          Padding(
                              padding:  EdgeInsets.fromLTRB(23, 0, 23, 0),
                              child: TextField(
                                style: TextStyle(
                                  fontSize: 14.0,

                                ),
                                cursorColor:  Color.fromRGBO(241, 123, 72, 1),
                                decoration: InputDecoration(
                                  hintText: 'Email',

                                  enabledBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(color: Color.fromRGBO(241, 123, 72, 1)),
                                  ),
                                  focusedBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(color: Color.fromRGBO(241, 123, 72, 1)),
                                  ),),
                                onChanged: (text) {
                                  value = text;
                                },
                              ))
                          ,

                          ]),



                  ],))),
      bottomNavigationBar: new Container(
        child: Container(

          color: Color.fromRGBO(241, 123, 72, 1),
          height: 52,

          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Align(
                alignment: FractionalOffset.bottomRight,
                child: FlatButton(
                  onPressed: (){
                    _navigateToNextScreen(context);
                  },
                  child: Row(

                    children: <Widget>[
                      Row(

                        children: <Widget>[
                          FlatButton(
                              onPressed: () {},
                              child: Column(
                                children: <Widget>[


                                ],)
                          ),
                        ],),


//Image.asset('assets/images/p_orange_next_icon.png',height: 20,width: 20,color: Color.fromRGBO(241, 123, 72, 1) ,),


                    ],
                  ),
                ),),
              Align(
                alignment: FractionalOffset.bottomRight,
                child: FlatButton(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Align(
                            alignment: FractionalOffset.center,
                            child:FlatButton(
                                onPressed: () {
                                  _navigateToNextScreen(context);
                                },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text("Next",style: TextStyle(color: Colors.white,fontSize: 16)),
                                    Icon(Icons.arrow_forward_ios,color: Colors.white,)
                                  ],)
                            ),),
                        ],),


                    ],
                  ),
                ),),

            ],),
        ),
      ),


    );
  }
  void _navigateToNextScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => PersonalInformationThird()),
    );
  }

}