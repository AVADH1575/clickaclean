class CellModel {
  int albumId;
  int id;
  String title;
  String url;
  String thumbnailUrl;

  CellModel({this.albumId, this.id, this.title, this.url, this.thumbnailUrl});

  factory CellModel.fromJson(Map<String, dynamic> json) {
    return CellModel(
        albumId: json['name'] as int,
        id: json['id'] as int,
        title: json['name'] as String,
        url: json['flag'] as String,
        thumbnailUrl: json['flag'] as String);
  }
}